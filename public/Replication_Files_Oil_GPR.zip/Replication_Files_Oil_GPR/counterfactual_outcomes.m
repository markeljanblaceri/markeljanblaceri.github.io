%==========================================================================
% Cutting the Flow: Geopolitical Disruptions to Russian Oil Supply and the
% Tails of Euro Area Inflation
%
% Markeljan Blaceri, University of Padova
%
% Replication files -- counterfactual: inflation without the disruption shocks
%==========================================================================
% Run after QFAVAR_main.m (full sample) and the exposure script (which writes
% output/Exposure_origin.xlsx). No re-estimation: everything is computed draw
% by draw from the saved posterior draws.
%
% The disruption shocks of cf_window (February 2022 - December 2023) are set
% to zero; all other shocks keep their estimated values. The contribution of
% the disruption shocks to the state vector is the convolution of the
% realized shocks with the impulse responses,
%     Delta_t = sum_s psi_{t-s} * eta_s ,   s in cf_window, s <= t,
% where eta_s is the innovation to the index (unit impact on the index) and
% psi the responses to a shock with unit impact on the index. The
% counterfactual state is z - Delta, and the counterfactual country
% quantiles follow from the measurement equation. Because the index is
% ordered first, eta_s = b_11 * eps_s, so psi * eta_s is exactly the effect
% of the structural shock eps_s. Euro area values are cross-country averages
% of the member-state quantiles (equal weights), in percentage points.
%
% Figures:
%   1  Euro area percentiles, fitted vs counterfactual
%   2  Contribution of the disruption shocks, euro area, month by month
%   3  Euro area upside and downside risk, fitted vs counterfactual
%   4  Member states, fitted vs counterfactual (measure set by show_meas)
%   5  Average contribution by member state vs pre-war exposure
%   6  Contribution by member state, month by month (three 7 x 3 blocks)
% Tables (LaTeX):
%   output/table_cf_contributions.tex  average contributions by member state
%   output/table_cf_peaks.tex          peak contributions and their month
%
% Helper functions (band, band_panel, separator, style_axes, impact,
% irf_unit, measure_fun, measure_name, lagmat) are in 'Additional functions'.
%==========================================================================

clear; clc; close all;
addpath('functions'); addpath('data'); addpath('Additional functions')

%---------------------------| USER INPUT |---------------------------------
res_file   = fullfile('output','QFAVAR_russia.mat');
cf_window  = {'2022Feb', '2023Dec'};   % GPR shocks removed in this window (first, last month)
shock_sign = 'all';                    % 'all' = remove all shocks (baseline); 'positive' = only escalations (eta > 0)
show_real  = true;                     % add realized inflation (EA average) to Figure 1
exp_file   = fullfile('output','Exposure_origin.xlsx');   % written by the exposure script
exp_var    = 'E_total';                % 'E_total' (oil + gas, baseline) or 'E_oil' (oil only)
exclude    = {};                       % countries dropped from the scatter, e.g. {'Slovakia'}
plot_from  = '2020Jan';                % first month shown in the figures
show_ctry  = 'all';                    % 'all' or a list, e.g. {'Germany','Italy','Estonia'}
show_meas  = 'upside';                 % by country: 'q10','q50','q90','upside','downside','uncertainty'
bands      = [16 84];                  % 68% credible bands
tab_file   = fullfile('output','table_cf_contributions.tex');   % LaTeX table: average contributions
tab_peak   = fullfile('output','table_cf_peaks.tex');           % LaTeX table: peak contributions
save_figs  = false;                    % true = export the figures to fig_dir
fig_dir    = fullfile('output','figures');
%--------------------------------------------------------------------------

load(res_file, 'F_draws','Phi_draws','OMEGA_draws','L_draws','g','quant', ...
     'n','ng','r','nq','names','dates','gpr_shock');
vars_in = who('-file', res_file);
if ismember('sample_end', vars_in), load(res_file, 'sample_end'); else, sample_end = []; end

[T, ~, ndraw] = size(F_draws);
nstate   = r*nq + ng;
kphi     = size(Phi_draws,1);
interF   = mod(kphi, nstate);
p        = (kphi - interF) / nstate;
interX   = size(L_draws,1) - (r + ng);              % 1 if the measurement equation had intercepts
perm_idx = [r*nq+1:nstate, 1:r*nq];                 % identification ordering [g, F] (GPR first)
ctry     = erase(names(:)', 'HICP.');

t0 = find(strcmp(dates, cf_window{1}));  t1 = find(strcmp(dates, cf_window{2}));
assert(~isempty(t0) && ~isempty(t1) && t0 > p && t1 >= t0, ...
       'cf_window dates not found or not valid (format e.g. ''2022Feb'').');

% Is OMEGA constant over time? (if not, use the impact matrix of each month)
nOm  = size(OMEGA_draws, 3);
tvOm = nOm > 1 && max(abs(OMEGA_draws(:,:,1,1) - OMEGA_draws(:,:,end,1)), [], 'all') > 1e-10;
if tvOm, fprintf('OMEGA varies over time: using the impact matrix of each month.\n'); end
om_t = @(t) min(t, nOm);                            % OMEGA index for month t

% Raw means and SDs of country inflation over the estimation sample (for pp)
x_raw = load_data(0, r, 1, 0, quant, 0, sample_end);
assert(size(x_raw,1) == T, 'Sample length of load_data differs from the saved draws.');
mu_c  = mean(x_raw);  sd_c = std(x_raw);

if ischar(show_ctry) && strcmp(show_ctry, 'all'), ic = 1:n;
else, [~, ic] = ismember(show_ctry, ctry);  ic = ic(ic > 0); end
nsel = numel(ic);

%% ======| Draw by draw (store euro area averages and the selected countries only)
EAact = zeros(T, nq, ndraw);  EAcf = EAact;          % euro area quantiles (pp)
Cact  = zeros(T, nsel, ndraw); Ccf = Cact;           % countries, measure show_meas (pp)
CQ    = zeros(n, nq, ndraw);                         % country contributions, average over cf_window (pp)
CW    = zeros(t1-t0+1, n, nq, ndraw);                % country contributions, month by month in cf_window (pp)
meas  = measure_fun(show_meas);
H     = T - t0 + 1;
for d = 1:ndraw
    Z   = [F_draws(:,:,d), g];                       % T x nstate (standardized)
    Phi = Phi_draws(:,:,d);
    A   = Phi(interF+1:end, :)';                     % nstate x (nstate*p)

    % Reduced-form residuals; the GPR innovation eta = u_GPR (unit impact on the index)
    X   = [ones(T-p, interF), lagmat(Z, p)];
    U   = Z(p+1:end,:) - X * Phi;
    eta = zeros(T,1);  eta(p+1:end) = U(:, gpr_shock);
    if strcmp(shock_sign, 'positive'), eta(eta < 0) = 0; end   % keep only escalations

    % Contribution of the GPR shocks in cf_window to the state vector
    Del = zeros(T, nstate);
    if tvOm
        for s = t0:t1
            psi = irf_unit(A, impact(OMEGA_draws(:,:,om_t(s),d), perm_idx), gpr_shock, p, T-s+1);
            Del(s:T,:) = Del(s:T,:) + eta(s) * psi;
        end
    else
        psi = irf_unit(A, impact(OMEGA_draws(:,:,end,d), perm_idx), gpr_shock, p, H);
        for s = t0:t1
            Del(s:T,:) = Del(s:T,:) + eta(s) * psi(1:T-s+1,:);
        end
    end

    % One-time check (first draw): convolution = re-simulation without the shocks
    if d == 1
        Zs = Z;
        for t = t0:T
            zt = zeros(1, nstate);
            if interF, zt = Phi(1,:); end
            for l = 1:p, zt = zt + Zs(t-l,:) * A(:, (l-1)*nstate+1:l*nstate)'; end
            e = U(t-p,:);
            if t <= t1
                B0 = impact(OMEGA_draws(:,:,om_t(t),d), perm_idx);
                e  = e - (B0(:,gpr_shock) * (eta(t)/B0(gpr_shock,gpr_shock)))';
            end
            Zs(t,:) = zt + e;
        end
        fprintf('Check: max |simulated - (z - contribution)| = %.2e (should be ~0)\n', ...
                max(abs(Zs - (Z - Del)), [], 'all'));
    end

    % Measurement equation: fitted country quantiles, actual and counterfactual (pp)
    Qa = zeros(T, n, nq);  Qc = Qa;
    for q = 1:nq
        lam = L_draws(interX+ng+1:interX+ng+r, :, q, d);   % r x n factor loadings
        gam = L_draws(interX+1:interX+ng, :, q, d);        % ng x n global loadings
        c0  = zeros(1, n);  if interX, c0 = L_draws(1, :, q, d); end
        fit = @(ZZ) c0 + ZZ(:, (q-1)*r+1:q*r) * lam + ZZ(:, r*nq+1:end) * gam;   % T x n, standardized
        Qa(:,:,q) = mu_c + sd_c .* fit(Z);
        Qc(:,:,q) = mu_c + sd_c .* fit(Z - Del);
    end
    EAact(:,:,d) = squeeze(mean(Qa, 2));  EAcf(:,:,d) = squeeze(mean(Qc, 2));
    Ma = meas(Qa);  Mc = meas(Qc);
    Cact(:,:,d) = Ma(:, ic);  Ccf(:,:,d) = Mc(:, ic);
    CQ(:,:,d)   = squeeze(mean(Qa(t0:t1,:,:) - Qc(t0:t1,:,:), 1));   % (n, nq)
    CW(:,:,:,d) = Qa(t0:t1,:,:) - Qc(t0:t1,:,:);                     % (months, n, nq)
end

%% ======| Summaries
tt   = find(strcmp(dates, plot_from)):T;
dn   = datenum(datetime(dates(tt), 'InputFormat', 'yyyyMMM'));
win  = t0:t1;
qtag = {'10th','50th','90th'};
fprintf('\nEuro area (average member state): contribution of the disruption shocks (%s), %s-%s\n', shock_sign, cf_window{:});
fprintf('%-16s %10s %10s %22s\n', '', 'peak (pp)', 'month', 'average over window (pp)');
for q = 1:nq
    C  = squeeze(EAact(:,q,:) - EAcf(:,q,:));         % (T, draws)
    md = median(C, 2);  [mx, im] = max(md(win));  im = win(im);
    av = mean(C(win,:), 1);
    fprintf('%-16s %10.2f %10s %10.2f [%5.2f, %5.2f]\n', [qtag{q} ' percentile'], mx, dates{im}, ...
            median(av), prctile(av, bands(1)), prctile(av, bands(2)));
end
risk  = {@(E) squeeze(E(:,3,:) - E(:,2,:)), @(E) squeeze(E(:,2,:) - E(:,1,:))};
rname = {'Upside Risk (Q90 - Q50)', 'Downside Risk (Q50 - Q10)'};
for k = 1:2
    C  = risk{k}(EAact) - risk{k}(EAcf);
    md = median(C, 2);  [mx, im] = max(abs(md(win)));  im = win(im);
    av = mean(C(win,:), 1);
    fprintf('%-16s %10.2f %10s %10.2f [%5.2f, %5.2f]\n', strtok(rname{k}, '('), md(im), dates{im}, ...
            median(av), prctile(av, bands(1)), prctile(av, bands(2)));
end

%% ======| Figures
if save_figs && ~exist(fig_dir, 'dir'), mkdir(fig_dir); end
fs    = 10;                                            % font size
mult1 = {'TitleFontSizeMultiplier', 1, 'LabelFontSizeMultiplier', 1};   % no automatic enlargement
c_act = [0 0 0];                                       % actual: black
c_A   = [0.13 0.47 0.80];  c_A_bd = [0.55 0.76 0.95];  % no GPR shocks: light blue (+ lighter band)
qn    = {'10th Percentile','50th Percentile','90th Percentile'};
ll    = {'Actual (fitted)', 'No geopolitical shocks'};
xa    = mean(x_raw, 2);                                % realized inflation, EA average (equal weights)
x_cf  = datenum(datetime(cf_window{1}, 'InputFormat', 'yyyyMMM'));

% Figure 1: euro area quantiles, actual vs counterfactual
fig1 = figure('Name','Counterfactual history: euro area','Color','w','Position',[50 100 1150 340]);
tiledlayout(1, nq, 'TileSpacing','compact', 'Padding','compact');
for q = 1:nq
    nexttile; hold on
    band(dn, squeeze(EAcf(tt,q,:)), bands, c_A_bd)
    plot(dn, mean(EAact(tt,q,:),3), '-', 'Color', c_act, 'LineWidth', 1.8);
    plot(dn, mean(EAcf(tt,q,:),3),  '-', 'Color', c_A,   'LineWidth', 1.6);
    if show_real && q == 2, plot(dn, xa(tt), ':', 'Color', [0.45 0.45 0.45], 'LineWidth', 1.2); end   % median panel only
    xline(x_cf, ':', 'Color', [0.4 0.4 0.4], 'HandleVisibility','off');
    hold off; style_axes(gca); xlim([dn(1) dn(end)]); datetick('x','yyyy','keeplimits')
    set(gca, 'FontSize', fs, mult1{:})
    title(qn{q}, 'FontSize', fs, 'FontWeight', 'normal')
    if q == 1
        ylabel('Inflation, % y/y', 'FontSize', fs);
    elseif q == 2
        l1 = ll;  if show_real, l1{3} = 'Realized (euro area average)'; end
        lg = legend(l1, 'Orientation','horizontal', 'Box','off', 'FontSize', fs);  lg.Layout.Tile = 'south';
    end
end
if save_figs, exportgraphics(fig1, fullfile(fig_dir, 'cf_ea.png'), 'Resolution', 300); end

% Figure 2: contribution of the GPR shocks (actual - counterfactual)
fig2 = figure('Name','Contribution of the disruption shocks','Color','w','Position',[50 100 1150 320]);
tiledlayout(1, nq, 'TileSpacing','compact', 'Padding','compact');
for q = 1:nq
    nexttile; hold on
    contA = squeeze(EAact(tt,q,:) - EAcf(tt,q,:));
    band(dn, contA, bands, c_A_bd);
    plot(dn, mean(contA,2), '-', 'Color', c_A, 'LineWidth', 1.6);
    yline(0, '--', 'Color', [0 0 0], 'HandleVisibility','off');
    xline(x_cf, '--', 'Color', [0.4 0.4 0.4], 'HandleVisibility','off');
    hold off; style_axes(gca); xlim([dn(1) dn(end)]); datetick('x','yyyy','keeplimits')
    set(gca, 'FontSize', fs, mult1{:})
    title(qn{q}, 'FontSize', fs, 'FontWeight', 'normal')
    if q == 1, ylabel('Percentage points', 'FontSize', fs); end
end
if save_figs, exportgraphics(fig2, fullfile(fig_dir, 'cf_ea_contribution.png'), 'Resolution', 300); end

% Figure 3: euro area upside and downside risk, actual vs counterfactual
fig3 = figure('Name','Counterfactual history: euro area risk','Color','w','Position',[50 100 900 340]);
tiledlayout(1, 2, 'TileSpacing','compact', 'Padding','compact');
for k = 1:2
    nexttile; hold on
    Ra = risk{k}(EAact(tt,:,:));  RA = risk{k}(EAcf(tt,:,:));
    band(dn, RA, bands, c_A_bd)
    plot(dn, mean(Ra,2), '-', 'Color', c_act, 'LineWidth', 1.8);
    plot(dn, mean(RA,2), '-', 'Color', c_A,   'LineWidth', 1.6);
    xline(x_cf, ':', 'Color', [0.4 0.4 0.4], 'HandleVisibility','off');
    hold off; style_axes(gca); xlim([dn(1) dn(end)]); datetick('x','yyyy','keeplimits')
    set(gca, 'FontSize', fs, mult1{:})
    title(rname{k}, 'FontSize', fs, 'FontWeight', 'normal')
    if k == 1
        ylabel('Percentage points', 'FontSize', fs);
        lg = legend(ll, 'Orientation','horizontal', 'Box','off', 'FontSize', fs);  lg.Layout.Tile = 'south';
    end
end
if save_figs, exportgraphics(fig3, fullfile(fig_dir, 'cf_ea_risk.png'), 'Resolution', 300); end

% Figure 4: countries, measure show_meas
mlong = measure_name(show_meas);
nrow  = 3;  ncol = ceil(nsel / nrow);  if nsel <= 6, nrow = 2; ncol = ceil(nsel/2); end
fig4 = figure('Name',['Counterfactual history: countries (' mlong ')'],'Color','w', ...
       'Position',[30 30 260*ncol 230*nrow]);
tiledlayout(nrow, ncol, 'TileSpacing','compact', 'Padding','compact');
for j = 1:nsel
    nexttile; hold on
    band(dn, squeeze(Ccf(tt,j,:)), bands, c_A_bd)
    plot(dn, mean(Cact(tt,j,:),3), '-', 'Color', c_act, 'LineWidth', 1.4);
    plot(dn, mean(Ccf(tt,j,:),3),  '-', 'Color', c_A,   'LineWidth', 1.2);
    hold off; style_axes(gca); xlim([dn(1) dn(end)]); datetick('x','yy','keeplimits')
    set(gca, 'FontSize', fs, mult1{:})
    title(ctry{ic(j)}, 'FontSize', fs, 'FontWeight', 'normal')
    if j == 1
        lg = legend(ll, 'Orientation','horizontal', 'Box','off', 'FontSize', fs);  lg.Layout.Tile = 'south';
    end
end
sgtitle(sprintf('%s (pp): fitted vs counterfactual', mlong), 'FontSize', fs, 'FontWeight', 'normal')
if save_figs, exportgraphics(fig4, fullfile(fig_dir, ['cf_countries_' show_meas '.png']), 'Resolution', 300); end

%% ======| Pre-war exposure (from the exposure script), used in Figure 5 and in the table
has_exp = isfile(exp_file);
expv    = nan(1, n);
if has_exp
    ET = readtable(exp_file, 'ReadRowNames', true, 'VariableNamingRule', 'preserve');
    [okE, iE] = ismember(ctry, ET.Properties.RowNames);
    expv(okE) = ET{iE(okE), exp_var};
    if strcmp(exp_var, 'E_oil'), xlab = 'Exposure to Russian oil'; else, xlab = 'Exposure to Russian oil and gas'; end
else
    warning('Exposure file not found (%s): run the exposure script first. Scatter and exposure column skipped.', exp_file);
end

%% ======| Figure 5: country contributions vs pre-war exposure
% y: contribution of the GPR shocks to each country's percentile, averaged
%    over cf_window (actual - counterfactual, pp); x: pre-war exposure.
% Slopes and fit statistics are printed in the console, not on the figure.
if has_exp
    iq  = find(~isnan(expv) & ~ismember(ctry, exclude));
    xe  = expv(iq)';  lab = ctry(iq);  nc = numel(xe);
    Xr  = [ones(nc,1) xe];
    qtit = {'10th percentile','50th percentile','90th percentile'};
    qcol = repmat(c_A, 3, 1);                           % same colour for the three percentiles
    fig5 = figure('Name','Contributions vs exposure','Color','w','Position',[60 120 1500 470]);
    tiledlayout(1, 3, 'TileSpacing','compact', 'Padding','compact');
    fprintf('\nCountry contributions (average %s-%s) on pre-war exposure (%s), %d countries:\n', ...
        cf_window{:}, exp_var, nc);
    fprintf('  %-16s %8s %8s %8s %6s | %8s %6s %6s\n', '', 'slope', 'p16', 'p84', 'P>0', 'OLS', 'p-val', 'R2');
    for q = 1:nq
        P   = squeeze(CQ(iq, q, :));                        % (countries, draws)
        pm  = mean(P, 2);  plo = prctile(P, bands(1), 2);  phi = prctile(P, bands(2), 2);
        Bq  = Xr \ P;  sq = Bq(2,:);  bq = Xr \ pm;
        e   = pm - Xr*bq;                                    % OLS on posterior means, HC1
        V   = (Xr'*Xr) \ (Xr' * (Xr .* e.^2)) / (Xr'*Xr) * nc/(nc-2);
        pv  = 2 * (1 - tcdf(abs(bq(2)/sqrt(V(2,2))), nc-2));
        R2  = 1 - sum(e.^2) / sum((pm - mean(pm)).^2);
        fprintf('  %-16s %8.3f %8.3f %8.3f %6.2f | %8.3f %6.3f %6.2f\n', qtit{q}, median(sq), ...
            prctile(sq,16), prctile(sq,84), mean(sq > 0), bq(2), pv, R2);
        nexttile; hold on
        errorbar(xe, pm, pm - plo, phi - pm, 'o', 'Color', qcol(q,:), 'MarkerFaceColor', qcol(q,:), ...
            'MarkerEdgeColor', qcol(q,:), 'CapSize', 0, 'LineWidth', 1);
        xx = linspace(min(xe), max(xe), 50)';
        plot(xx, bq(1) + bq(2)*xx, '--', 'Color', [0 0 0], 'LineWidth', 1.2);
        text(xe, pm, strcat({'  '}, lab(:)), 'FontSize', fs, 'VerticalAlignment', 'bottom');
        yline(0, '-', 'Color', [0 0 0], 'LineWidth', 0.6);
        hold off; style_axes(gca);
        xl = xlim; xlim([min(0, xl(1)) max(xl(2), max(xe) * 1.25)])                       % room for the label of the most exposed country
        set(gca, 'FontSize', fs, 'TitleFontSizeMultiplier', 1, 'LabelFontSizeMultiplier', 1)  % no automatic enlargement
        title(qtit{q}, 'FontSize', fs, 'FontWeight', 'normal')
        xlabel(xlab, 'FontSize', fs)
        if q == 1, ylabel('Average contribution of the shocks (pp)', 'FontSize', fs); end
    end
    if save_figs, exportgraphics(fig5, fullfile(fig_dir, 'cf_exposure.png'), 'Resolution', 300); end
end
% Country contributions (posterior means), printed
CT = array2table(round(mean(CQ, 3), 2), 'RowNames', ctry(:), 'VariableNames', {'Q10','Q50','Q90'});
fprintf('Average contribution by country, %s-%s (pp, posterior mean):\n', cf_window{:});
disp(CT)

%% ======| Figure 6: monthly contributions by member state, one panel per percentile
% Same layout as the country IRF figure: three 7 x 3 blocks (10th, 50th, 90th percentile).
% Contribution of the disruption shocks (fitted - counterfactual), month by month over
% cf_window, posterior mean and 68% band, pp.
fs_s = 8;                                                    % font size (63 small panels)
dw = datenum(datetime(dates(t0:t1), 'InputFormat', 'yyyyMMM'));
dw = dw(:)';                                                 % row vector for band_panel
xt = datenum(datetime({'2022Mar','2022Sep','2023Mar','2023Sep'}, 'InputFormat','yyyyMMM'));
qnames_long = {'10th Percentile', '50th Percentile', '90th Percentile'};

fig6 = figure('Name', 'Monthly contributions by member state', 'Color', 'w', 'Position', [50 20 1600 800]);
n_rows = 7;  n_cols_per_panel = 3;
total_cols = (n_cols_per_panel * 3) + 2;                     % 3 panels + 2 separators
tiledlayout(n_rows, total_cols, 'TileSpacing', 'compact', 'Padding', 'compact');
panel_offsets = [0, n_cols_per_panel + 1, (n_cols_per_panel * 2) + 2];
separator(n_cols_per_panel + 1, n_rows)                      % column 4
separator((n_cols_per_panel * 2) + 2, n_rows)                % column 8
for q = 1:nq
    for i = 1:n
        row = ceil(i / n_cols_per_panel);
        col = mod(i - 1, n_cols_per_panel) + 1 + panel_offsets(q);
        nexttile((row - 1) * total_cols + col)
        D = squeeze(CW(:, i, q, :));                         % (months, draws)
        band_panel(dw, D, bands, c_A_bd, c_A, [0 0 0], 1.4, 2.5)
        set(gca, 'XTick', xt, 'XTickLabel', {'Mar 22','Sep 22','Mar 23','Sep 23'}, 'FontSize', fs_s, ...
            'LineWidth', 0.6, 'TitleFontSizeMultiplier', 1, 'LabelFontSizeMultiplier', 1)
        if i == 2
            title(sprintf('%s\n%s', qnames_long{q}, ctry{i}), 'FontSize', fs_s, 'FontWeight', 'normal')
        else
            title(ctry{i}, 'FontSize', fs_s, 'FontWeight', 'normal')
        end
        if mod(i - 1, n_cols_per_panel) == 0, ylabel('pp', 'FontSize', fs_s); end
        if row ~= n_rows && i ~= n, set(gca, 'XTickLabel', {}); end
    end
end
if save_figs, exportgraphics(fig6, fullfile(fig_dir, 'country_contribution.png'), 'Resolution', 300); end

%% ======| Table: contributions of the disruption shocks (actual - counterfactual), LaTeX
% Average over cf_window of (fitted - counterfactual) percentile, pp.
% Rows: member states (alphabetical) + euro area (cross-country average).
% Each cell: posterior mean, with the 68% band on the line below.
CEA  = squeeze(mean(EAact(t0:t1,:,:) - EAcf(t0:t1,:,:), 1));   % (nq, draws)
[~, oa] = sort(ctry);
fnum = @(x) strrep(sprintf('%.2f', round(x,2) + 0), '-', '$-$');   % proper minus sign, no -0.00
fmtc = @(D) {fnum(mean(D)), ['[' fnum(prctile(D,bands(1))) ', ' fnum(prctile(D,bands(2))) ']']};
mlong_w = @(s) datestr(datetime(s,'InputFormat','yyyyMMM'), 'mmmm yyyy');
if ~exist('output','dir'), mkdir('output'); end

fid = fopen(tab_file, 'w');
fprintf(fid, '\\begin{table}[!htbp]\n\\centering\n');
fprintf(fid, '\\caption{Contribution of Geopolitical Disruptions to Inflation by Member State, %s -- %s}\n', ...
        mlong_w(cf_window{1}), mlong_w(cf_window{2}));
fprintf(fid, '\\label{tab:cf_contributions}\n{\\small\n');
if has_exp
    fprintf(fid, '\\begin{tabular}{lcccc}\n\\hline\\hline\n');
    fprintf(fid, ' & Pre-war & \\multicolumn{3}{c}{Contribution (pp)} \\\\\n\\cline{3-5}\n');
    fprintf(fid, ' & exposure & 10th pct. & 50th pct. & 90th pct. \\\\\n\\hline\n');
else
    fprintf(fid, '\\begin{tabular}{lccc}\n\\hline\\hline\n');
    fprintf(fid, ' & \\multicolumn{3}{c}{Contribution (pp)} \\\\\n\\cline{2-4}\n');
    fprintf(fid, ' & 10th pct. & 50th pct. & 90th pct. \\\\\n\\hline\n');
end
for k = 1:n
    i  = oa(k);
    c1 = cell(nq,1);  c2 = cell(nq,1);
    for q = 1:nq, cc = fmtc(squeeze(CQ(i,q,:))); c1{q} = cc{1}; c2{q} = cc{2}; end
    if has_exp
        fprintf(fid, '%s & %.2f & %s & %s & %s \\\\\n', ctry{i}, expv(i), c1{:});
        fprintf(fid, ' & & {\\scriptsize %s} & {\\scriptsize %s} & {\\scriptsize %s} \\\\[2pt]\n', c2{:});
    else
        fprintf(fid, '%s & %s & %s & %s \\\\\n', ctry{i}, c1{:});
        fprintf(fid, ' & {\\scriptsize %s} & {\\scriptsize %s} & {\\scriptsize %s} \\\\[2pt]\n', c2{:});
    end
end
c1 = cell(nq,1);  c2 = cell(nq,1);
for q = 1:nq, cc = fmtc(CEA(q,:)'); c1{q} = cc{1}; c2{q} = cc{2}; end
fprintf(fid, '\\hline\n');
if has_exp
    fprintf(fid, 'Euro area (average) & %.2f & %s & %s & %s \\\\\n', mean(expv,'omitnan'), c1{:});
    fprintf(fid, ' & & {\\scriptsize %s} & {\\scriptsize %s} & {\\scriptsize %s} \\\\\n', c2{:});
else
    fprintf(fid, 'Euro area (average) & %s & %s & %s \\\\\n', c1{:});
    fprintf(fid, ' & {\\scriptsize %s} & {\\scriptsize %s} & {\\scriptsize %s} \\\\\n', c2{:});
end
fprintf(fid, '\\hline\\hline\n\\end{tabular}\n}\n\\par\\vspace{1em}\n{\\footnotesize\n\\begin{minipage}{0.92\\linewidth}\n\\raggedright\n');
fprintf(fid, ['\\textit{Note:} Contribution of the geopolitical disruption shocks to the 10th, 50th, and 90th percentiles of inflation, ' ...
              'computed as the difference between the fitted percentile and its counterfactual path without the disruption shocks of %s -- %s, ' ...
              'averaged over that period, in percentage points. Posterior means; 16th--84th percentile credible bands in brackets. '], ...
        mlong_w(cf_window{1}), mlong_w(cf_window{2}));
if has_exp
    fprintf(fid, 'Pre-war exposure to Russian oil and gas in 2020, in percent of the consumer basket, as defined in Section~\\ref{why_differ}. ');
end
fprintf(fid, 'Euro area (average) is the unweighted average of the 21 member states. \\\\\n\\textit{Sample: January 2000 -- December 2025.}\n\\end{minipage}\n}\n\\end{table}\n');
fclose(fid);
fprintf('LaTeX table written to %s\n', tab_file);

%% ======| Table: peak contributions (actual - counterfactual), LaTeX
% For each member state and percentile: the month in cf_window in which the
% posterior mean contribution is largest, the contribution in that month
% (posterior mean) and its 68% band.
wd   = dates(t0:t1);
mshort = @(s) datestr(datetime(s,'InputFormat','yyyyMMM'), 'mmm yyyy');
CEAw = EAact(t0:t1,:,:) - EAcf(t0:t1,:,:);                      % (months, nq, draws)

fid = fopen(tab_peak, 'w');
fprintf(fid, '\\begin{table}[!htbp]\n\\centering\n');
fprintf(fid, '\\caption{Peak Contribution of Geopolitical Disruptions to Inflation by Member State}\n');
fprintf(fid, '\\label{tab:cf_peaks}\n{\\small\n');
fprintf(fid, '\\begin{tabular}{lccc}\n\\hline\\hline\n');
fprintf(fid, ' & \\multicolumn{3}{c}{Peak contribution (pp)} \\\\\n\\cline{2-4}\n');
fprintf(fid, ' & 10th pct. & 50th pct. & 90th pct. \\\\\n\\hline\n');
PkTbl = zeros(n, nq);  PkMon = strings(n, nq);
for k = 1:n
    i = oa(k);  c1 = cell(nq,1);  c2 = cell(nq,1);
    for q = 1:nq
        Dm = squeeze(CW(:, i, q, :));                           % (months, draws)
        [~, im] = max(mean(Dm, 2));
        D  = Dm(im, :)';
        c1{q} = sprintf('%s {\\scriptsize (%s)}', fnum(mean(D)), mshort(wd{im}));
        c2{q} = ['[' fnum(prctile(D,bands(1))) ', ' fnum(prctile(D,bands(2))) ']'];
        PkTbl(i,q) = mean(D);  PkMon(i,q) = mshort(wd{im});
    end
    fprintf(fid, '%s & %s & %s & %s \\\\\n', ctry{i}, c1{:});
    fprintf(fid, ' & {\\scriptsize %s} & {\\scriptsize %s} & {\\scriptsize %s} \\\\[2pt]\n', c2{:});
end
c1 = cell(nq,1);  c2 = cell(nq,1);
for q = 1:nq
    Dm = squeeze(CEAw(:, q, :));
    [~, im] = max(mean(Dm, 2));
    D  = Dm(im, :)';
    c1{q} = sprintf('%s {\\scriptsize (%s)}', fnum(mean(D)), mshort(wd{im}));
    c2{q} = ['[' fnum(prctile(D,bands(1))) ', ' fnum(prctile(D,bands(2))) ']'];
    fprintf('Euro area, %s percentile: peak contribution %.2f pp in %s\n', qtag{q}, mean(D), mshort(wd{im}));
end
fprintf(fid, '\\hline\n');
fprintf(fid, 'Euro area (average) & %s & %s & %s \\\\\n', c1{:});
fprintf(fid, ' & {\\scriptsize %s} & {\\scriptsize %s} & {\\scriptsize %s} \\\\\n', c2{:});
fprintf(fid, '\\hline\\hline\n\\end{tabular}\n}\n\\par\\vspace{1em}\n{\\footnotesize\n\\begin{minipage}{0.92\\linewidth}\n\\raggedright\n');
fprintf(fid, ['\\textit{Note:} Largest contribution of the geopolitical disruption shocks of %s -- %s to the 10th, 50th, and 90th percentiles of inflation, ' ...
              'computed as the difference between the fitted percentile and its counterfactual path, in percentage points. ' ...
              'For each member state and percentile, the peak is the month within that period in which the posterior mean contribution is largest; ' ...
              'the month is reported in parentheses. Posterior means; 16th--84th percentile credible bands in brackets. ' ...
              'Euro area (average) is the unweighted average of the 21 member states. \\\\\n\\textit{Sample: January 2000 -- December 2025.}\n'], ...
        mlong_w(cf_window{1}), mlong_w(cf_window{2}));
fprintf(fid, '\\end{minipage}\n}\n\\end{table}\n');
fclose(fid);
fprintf('LaTeX table written to %s\n', tab_peak);