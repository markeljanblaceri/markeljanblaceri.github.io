%==========================================================================
% Cutting the Flow: Geopolitical Disruptions to Russian Oil Supply and the
% Tails of Euro Area Inflation
%
% Markeljan Blaceri, University of Padova
%
% Replication files -- figures of the main results and of the index
%==========================================================================
% Run after QFAVAR_main.m (full sample). Loads output/QFAVAR_russia.mat and
% produces:
%
%   Figure A  Disruption index over time, with the main events labelled
%   Figure B  Identified disruption shocks and the shock size in the IRFs
%   Figure C  Euro area inflation percentiles: impulse responses
%   Figure D  Euro area upside and downside risk: impulse responses
%   Figure E  Member-state inflation percentiles: impulse responses
%   Figure F  Member-state upside and downside risk: impulse responses
%   Figure G  Global factors: impulse responses
%   Figure H  Fitted conditional quantiles vs realized inflation (euro area)
%   Figure I  Fitted conditional quantiles vs realized inflation (member states)
%
% Responses are de-standardized draw by draw:
%   - member-state responses -> percentage points (x country inflation SD)
%   - quantile factors       -> percentage points (x cross-country mean SD)
%   - global factors         -> own units (x variable SD)
% The shock raises the disruption index by one standard deviation on impact
% (set shock_pts to change this). Horizon 1 on the x-axis = impact.
% Upside risk = Q90 - Q50, downside risk = Q50 - Q10, computed draw by draw.
%
% Helper functions (band_panel, separator, style_axes) are in the folder
% 'Additional functions'.
%==========================================================================

clear; clc; close all;
addpath('functions'); addpath('data'); addpath('Additional functions')

%---------------------------| USER INPUT |---------------------------------
res_file   = fullfile('output','QFAVAR_russia.mat');
bands      = [16 84];          % 68% credible bands
shock_pts  = [];               % [] = one-SD shock; e.g. 100 = shock of +100 index points
fac_scale  = 'ea_avg';         % 'ea_avg' (cross-country mean SD) or 'austria' (normalizing country)
ea_risk    = 'factor';         % euro area risk: 'factor' (from the quantile factors) or 'avg' (country average)
save_figs  = false;            % true = export all figures to fig_dir
fig_dir    = fullfile('output','figures');
%--------------------------------------------------------------------------

% Common style (light blue throughout; box and grid from style_axes)
c_line = [0.13 0.47 0.80];     % posterior mean
c_band = [0.55 0.76 0.95];     % 68% band
c_dark = [0.05 0.20 0.50];     % second series where one is needed (dark navy)
c_zero = [0 0 0];              % zero line
c_ref  = [0.35 0.35 0.35];     % reference lines
fs     = 10;                   % font size, single-panel and small multi-panel figures
fs_s   = 8;                    % font size, 63-panel country figures
mult1  = {'TitleFontSizeMultiplier', 1, 'LabelFontSizeMultiplier', 1};   % no automatic enlargement

if save_figs && ~exist(fig_dir, 'dir'), mkdir(fig_dir); end

%% =====================================================================
%  Load estimates and de-standardize
%  =====================================================================
load(res_file, 'firf_save','yirf_save','F_draws','L_draws','Phi_draws','g', ...
    'quant','nhor','n','ng','r','nq','names','namesg','dates','gpr_shock');
vars_in = who('-file', res_file);
if ismember('sample_end', vars_in), load(res_file, 'sample_end'); else, sample_end = []; end

[x_raw,~,~,~,~,g_raw] = load_data(0, r, 1, 0, quant, 0, sample_end);   % same sample as the estimation
sd_c = std(x_raw);  mu_c = mean(x_raw);  sd_g = std(g_raw);
switch fac_scale
    case 'ea_avg',  sd_f = mean(sd_c);
    case 'austria', sd_f = sd_c(1);
end
ctry = erase(names(:)', 'HICP.');
[T, ~, ndraw] = size(F_draws);

if isempty(shock_pts), shock_scale = 1; else, shock_scale = shock_pts / sd_g(1); end
shock_size = sd_g(1) * shock_scale;
fprintf('Index SD = %.1f points; shock in the IRFs = %.1f points\n', sd_g(1), shock_size);

% Responses to the disruption shock, draw by draw
irfpanel = squeeze(yirf_save(:,:,gpr_shock,:)) .* repmat(sd_c, 1, nq) * shock_scale;  % (h, n*nq, draws), pp
S        = squeeze(firf_save(:,:,gpr_shock,:)) * shock_scale;
irfarray = S(:,1:r*nq,:) * sd_f;                                % quantile factors, pp
irfglob  = S(:,r*nq+1:end,:) .* reshape(sd_g,1,[],1);           % global factors, own units

% Risk measures
Yq = @(q) irfpanel(:,(q-1)*n+1:q*n,:);
UP = Yq(3) - Yq(2);                                             % country upside risk
DN = Yq(2) - Yq(1);                                             % country downside risk
switch ea_risk
    case 'factor'
        upside_risk   = squeeze(irfarray(:,3,:) - irfarray(:,2,:));
        downside_risk = squeeze(irfarray(:,2,:) - irfarray(:,1,:));
    case 'avg'
        upside_risk   = squeeze(mean(UP,2));
        downside_risk = squeeze(mean(DN,2));
end

hz = (1:nhor);                                                  % 1 = impact
qnames = {'10th Percentile', '50th Percentile', '90th Percentile'};

%% =====================================================================
%  Figure A: disruption index over time, with the main events labelled
%  =====================================================================
% Time runs down the vertical axis, as in Caldara and Iacoviello (2022).
% The n_label largest months (at least min_gap months apart) are marked and
% labelled with the events below; months not in the list show the date only.
n_label = 14;
min_gap = 4;
fs_ev   = 8;                                                    % event labels
events = { ...
  '2006-01', 'Russia-Ukraine gas dispute';
  '2007-01', 'Druzhba oil pipeline halted (Russia-Belarus dispute)';
  '2008-08', 'Russo-Georgian war';
  '2009-01', 'Russia-Ukraine gas crisis';
  '2014-03', 'Annexation of Crimea';
  '2014-07', 'MH17; EU sectoral sanctions';
  '2014-09', 'Sanctions extended to Russian oil companies';
  '2015-02', 'Minsk II; escalation in eastern Ukraine';
  '2016-12', 'Russia joins OPEC+ production cut';
  '2018-03', 'Skripal poisoning; new US sanctions';
  '2019-04', 'Druzhba pipeline contamination';
  '2020-03', 'Saudi-Russia oil price war';
  '2021-12', 'Russian troop build-up at Ukraine border';
  '2022-02', 'Russia invades Ukraine';
  '2022-03', ['War in Ukraine;' newline '         US bans Russian oil imports'];
  '2022-06', 'EU 6th package: oil embargo';
  '2022-09', 'Nord Stream sabotage';
  '2022-10', 'OPEC+ output cut; Crimean bridge attack';
  '2022-12', 'EU crude embargo + price cap';
  '2023-02', 'EU refined products embargo';
  '2023-06', 'Wagner mutiny';
  '2024-01', 'Drone strikes on Russian refineries and terminals';
  '2024-08', 'Ukrainian incursion into Kursk';
  '2025-03', 'Talks on energy-infrastructure ceasefire';
  '2025-10', 'US sanctions on Rosneft and Lukoil; EU 19th package'};

Tm = readtable(fullfile('data','Main Data.xlsx'), 'Sheet', 'Global', 'VariableNamingRule', 'preserve');
tm = Tm{:, 'month'};  ym = Tm{:, 'russia_gpr'};
ok = ~isnat(tm) & ~isnan(ym);  tm = tm(ok);  ym = ym(ok);
tm = dateshift(tm, 'start', 'month') + days(14);                % monthly values plotted mid-month

[~, ord] = sort(ym, 'descend');  pk = [];
for j = ord'
    if all(abs(calmonths(between(tm(pk), tm(j), 'months'))) >= min_gap), pk(end+1) = j; end %#ok<AGROW>
    if numel(pk) == n_label, break; end
end
pk = sort(pk);
labs = strings(numel(pk), 1);
fprintf('\nFigure A, marked months:\n');
for k = 1:numel(pk)
    key  = string(datestr(tm(pk(k)), 'yyyy-mm'));
    hit  = find(strcmp(events(:,1), key), 1);
    dstr = string(datestr(tm(pk(k)), 'yyyy/mm'));
    if isempty(hit), labs(k) = dstr; else, labs(k) = dstr + ": " + events{hit,2}; end
    fprintf('  %s  %7.1f  %s\n', key, ym(pk(k)), labs(k));
end

xm = datenum(tm);
figA = figure('Name','A: Disruption index','Color','w','Position',[100 40 760 980]); hold on
plot(ym, xm, '-', 'Color', c_line, 'LineWidth', 1.2);
plot(ym(pk), xm(pk), 'o', 'MarkerSize', 6, 'MarkerFaceColor', c_dark, 'MarkerEdgeColor', 'none');
text(ym(pk), xm(pk), "  \leftarrow " + labs, 'FontSize', fs_ev, 'VerticalAlignment', 'middle');
hold off
set(gca, 'YDir', 'reverse');  ylim([xm(1) xm(end)] + [-60 60]);
yt = datenum(datetime(year(tm(1)):2:year(tm(end)), 1, 1));
set(gca, 'YTick', yt, 'YTickLabel', string(year(datetime(yt, 'ConvertFrom', 'datenum'))));
xl = xlim;  xlim([0 xl(2) * 1.45]);                             % room for the labels
style_axes(gca);  set(gca, 'FontSize', fs, mult1{:})
xlabel('Russian geopolitical oil supply disruption index', 'FontSize', fs)
if save_figs, exportgraphics(figA, fullfile(fig_dir, 'gpr_events.png'), 'Resolution', 300); end

%% =====================================================================
%  Figure B: identified disruption shocks and the shock size in the IRFs
%  =====================================================================
nstate = r*nq + ng;
interF = mod(size(Phi_draws,1), nstate);
p_lag  = (size(Phi_draws,1) - interF) / nstate;
eta = NaN(T, ndraw);                                            % identified shocks, index points
for d = 1:ndraw
    Z = [F_draws(:,:,d), g];
    X = ones(T-p_lag, interF);
    for l = 1:p_lag, X = [X, Z(p_lag+1-l:T-l, :)]; end %#ok<AGROW>
    U = Z(p_lag+1:end,:) - X * Phi_draws(:,:,d);
    eta(p_lag+1:end, d) = U(:, gpr_shock) * sd_g(1);            % unit impact -> index points
end
eta_md = median(eta, 2);
[~, io] = sort(eta_md, 'descend', 'MissingPlacement', 'last');
fprintf('\nFigure B: shock in the IRFs %.1f points = %.2f SD of the identified shocks (SD = %.1f points)\n', ...
    shock_size, shock_size / std(eta_md, 'omitnan'), std(eta_md, 'omitnan'));
for j = 1:8, fprintf('   %s  %7.1f points\n', dates{io(j)}, eta_md(io(j))); end

% Labels: 'up' = rotated above the bar; 'left' = horizontal, left of the bar top
lab_shk = {'2008Aug','up'; '2014Mar','up'; '2022Feb','left'; '2022Mar','up'; '2022Sep','up'};
dn = datenum(datetime(dates, 'InputFormat', 'yyyyMMM'));
figB = figure('Name','B: Identified shocks','Color','w','Position',[50 100 1000 360]); hold on
bar(dn, eta_md, 1, 'FaceColor', c_line, 'EdgeColor', 'none');
yline(shock_size, '--', 'Color', c_ref, 'LineWidth', 1.4);
yline(0, '-', 'Color', c_zero, 'LineWidth', 0.5, 'HandleVisibility', 'off');
for j = 1:size(lab_shk, 1)
    t = find(strcmp(dates, lab_shk{j,1}));
    if isempty(t), continue; end
    txt = datestr(dn(t), 'mmm yyyy');
    switch lab_shk{j,2}
        case 'up'
            text(dn(t), max(eta_md(t),0), ['  ' txt], 'Rotation', 90, 'FontSize', fs_ev, ...
                 'Color', [0.3 0.3 0.3], 'VerticalAlignment', 'middle');
        case 'left'
            text(dn(t) - 20, eta_md(t), [txt ' '], 'FontSize', fs_ev, 'Color', [0.3 0.3 0.3], ...
                 'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle');
    end
end
hold off
style_axes(gca);  set(gca, 'FontSize', fs, mult1{:})
xlim([dn(1) dn(end)]);  datetick('x', 'yyyy', 'keeplimits')
yl = ylim;  ylim([yl(1) max(yl(2), shock_size) * 1.15]);
ylabel('Index points', 'FontSize', fs)
legend({'Identified shock (posterior median)', sprintf('Shock in the IRFs (%.0f points)', shock_size)}, ...
    'Location', 'northwest', 'Box', 'off', 'FontSize', fs)
if save_figs, exportgraphics(figB, fullfile(fig_dir, 'gpr_shocks.png'), 'Resolution', 300); end

%% =====================================================================
%  Figure C: euro area inflation percentiles
%  =====================================================================
figC = figure('Name','C: Euro area percentiles','Color','w','Position',[50 100 1000 320]);
tiledlayout(1, nq, 'TileSpacing', 'compact', 'Padding', 'compact');
for q = 1:nq
    nexttile
    band_panel(hz, squeeze(irfarray(:,q,:)), bands, c_band, c_line, c_zero, 2.2)
    set(gca, 'FontSize', fs, 'LineWidth', 0.8, mult1{:})
    title(qnames{q}, 'FontSize', fs, 'FontWeight', 'normal')
    if q == 1, ylabel('Percentage points', 'FontSize', fs); end
end
if save_figs, exportgraphics(figC, fullfile(fig_dir, 'ea_percentiles.png'), 'Resolution', 300); end

%% =====================================================================
%  Figure D: euro area upside and downside risk
%  =====================================================================
figD = figure('Name','D: Euro area risk','Color','w','Position',[50 100 900 370]);
tiledlayout(1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
rk = {upside_risk, downside_risk};  rn = {'Upside Risk', 'Downside Risk'};
for k = 1:2
    nexttile
    band_panel(hz, rk{k}, bands, c_band, c_line, c_zero, 2.3)
    set(gca, 'FontSize', fs, 'LineWidth', 0.8, mult1{:})
    title(rn{k}, 'FontSize', fs, 'FontWeight', 'normal')
    ylabel('Percentage points', 'FontSize', fs)
end
if save_figs, exportgraphics(figD, fullfile(fig_dir, 'ea_risks.png'), 'Resolution', 300); end

%% =====================================================================
%  Figure E: member-state inflation percentiles (three 7 x 3 blocks)
%  =====================================================================
figE = figure('Name','E: Member-state percentiles','Color','w','Position',[50 20 1600 800]);
n_rows = 7;  n_cols_per_panel = 3;
total_cols = (n_cols_per_panel * 3) + 2;                        % 3 blocks + 2 separators
tiledlayout(n_rows, total_cols, 'TileSpacing', 'compact', 'Padding', 'compact');
panel_offsets = [0, n_cols_per_panel + 1, (n_cols_per_panel * 2) + 2];
separator(n_cols_per_panel + 1, n_rows)
separator((n_cols_per_panel * 2) + 2, n_rows)
for q = 1:nq
    for i = 1:n
        row = ceil(i / n_cols_per_panel);
        col = mod(i - 1, n_cols_per_panel) + 1 + panel_offsets(q);
        nexttile((row - 1) * total_cols + col)
        band_panel(hz, squeeze(irfpanel(:, (q-1)*n + i, :)), bands, c_band, c_line, c_zero, 1.4, 2.5)
        set(gca, 'FontSize', fs_s, 'LineWidth', 0.6, mult1{:})
        if i == 2, title(sprintf('%s\n%s', qnames{q}, ctry{i}), 'FontSize', fs_s, 'FontWeight', 'normal')
        else,      title(ctry{i}, 'FontSize', fs_s, 'FontWeight', 'normal'); end
        if mod(i - 1, n_cols_per_panel) == 0, ylabel('pp', 'FontSize', fs_s); end
        if row ~= n_rows && i ~= n, set(gca, 'XTickLabel', {}); end
    end
end
if save_figs, exportgraphics(figE, fullfile(fig_dir, 'country_percentiles.png'), 'Resolution', 300); end

%% =====================================================================
%  Figure F: member-state upside and downside risk (two 7 x 3 blocks)
%  =====================================================================
figF = figure('Name','F: Member-state risk','Color','w','Position',[50 20 1200 650]);
total_cols = (n_cols_per_panel * 2) + 1;                        % 2 blocks + 1 separator
tiledlayout(n_rows, total_cols, 'TileSpacing', 'compact', 'Padding', 'compact');
separator(n_cols_per_panel + 1, n_rows)
risk_data  = {UP, DN};
risk_shift = [0, n_cols_per_panel + 1];
for k = 1:2
    for i = 1:n
        row = ceil(i / n_cols_per_panel);
        col = mod(i - 1, n_cols_per_panel) + 1 + risk_shift(k);
        nexttile((row - 1) * total_cols + col)
        band_panel(hz, squeeze(risk_data{k}(:, i, :)), bands, c_band, c_line, c_zero, 1.3, 2.5)
        set(gca, 'FontSize', fs_s, 'LineWidth', 0.6, mult1{:})
        if i == 2, title(sprintf('%s\n%s', rn{k}, ctry{i}), 'FontSize', fs_s, 'FontWeight', 'normal')
        else,      title(ctry{i}, 'FontSize', fs_s, 'FontWeight', 'normal'); end
        if col == 1 + risk_shift(k), ylabel('pp', 'FontSize', fs_s); end
        if row ~= n_rows && i ~= n, set(gca, 'XTickLabel', {}); end
    end
end
if save_figs, exportgraphics(figF, fullfile(fig_dir, 'country_risks.png'), 'Resolution', 300); end

%% =====================================================================
%  Figure G: global factors, including the disruption index
%  =====================================================================
nice = struct('russia_gpr','Disruption index', 'oil_inflation','Oil price inflation', ...
    'gas_inflation','Gas price inflation', 'ciss','CISS', 'gscpi','GSCPI', ...
    'urate','Unemployment rate', 'shadow_rate','Shadow rate');
units = struct('russia_gpr','Index points', 'ciss','Index (0-1)', 'gscpi','Std. dev.');
gnames = namesg;
for j = 1:ng, if isfield(nice, namesg{j}), gnames{j} = nice.(namesg{j}); end, end
figG = figure('Name','G: Global factors','Color','w','Position',[50 100 1100 520]);
tiledlayout(2, ceil(ng/2), 'TileSpacing', 'compact', 'Padding', 'compact');
for j = 1:ng
    nexttile
    band_panel(hz, squeeze(irfglob(:, j, :)), bands, c_band, c_line, c_zero, 2.0)
    set(gca, 'FontSize', fs, 'LineWidth', 0.8, mult1{:})
    title(gnames{j}, 'FontSize', fs, 'FontWeight', 'normal', 'Interpreter', 'none')
    if isfield(units, namesg{j}), ylabel(units.(namesg{j}), 'FontSize', fs)
    else, ylabel('Percentage points', 'FontSize', fs); end
end
if save_figs, exportgraphics(figG, fullfile(fig_dir, 'global_variables.png'), 'Resolution', 300); end

%% =====================================================================
%  Figures H-I: fitted conditional quantiles vs realized inflation
%  =====================================================================
% Q_tau(i,t) = mu_i + sd_i * (c_i + lambda_i,tau * Pi_tau,t + gamma_i,tau' * G_t),
% averaged over the posterior draws. Months in which realized inflation is
% outside the fitted 10th-90th percentile range are marked; in-sample, about
% 10% of months should fall on each side (coverage table below). The euro
% area panel averages the member-state quantiles and is descriptive only.
mark_date = datetime(2022,2,24);                                % vertical line: invasion
interX = size(L_draws,1) - (r + ng);
Q = zeros(T, n, nq);
for d = 1:ndraw
    for q = 1:nq
        lam = L_draws(interX+ng+1:interX+ng+r, :, q, d);
        gam = L_draws(interX+1:interX+ng, :, q, d);
        c0  = zeros(1, n);  if interX, c0 = L_draws(1, :, q, d); end
        fitq = c0 + F_draws(:, (q-1)*r+1:q*r, d) * lam + g * gam;
        Q(:,:,q) = Q(:,:,q) + (mu_c + sd_c .* fitq) / ndraw;
    end
end
below = mean(x_raw < Q(:,:,1), 1);  above = mean(x_raw > Q(:,:,3), 1);
fprintf('\nShare of months outside the fitted 10th-90th percentile range (target: about 10%% each):\n');
disp(array2table(round(100*[below' above'], 1), 'RowNames', ctry(:), ...
     'VariableNames', {'Below_Q10_pct','Above_Q90_pct'}))
fprintf('All countries: below Q10 = %.1f%%, above Q90 = %.1f%%\n', 100*mean(below), 100*mean(above));

% Figure H: euro area
xa = mean(x_raw, 2);  Qa = squeeze(mean(Q, 2));
figH = figure('Name','H: Fitted quantiles, euro area','Color','w','Position',[60 120 1000 420]); hold on
fill([dn; flipud(dn)], [Qa(:,1); flipud(Qa(:,3))], c_band, 'EdgeColor','none', 'FaceAlpha', 0.6);
plot(dn, Qa(:,2), '-', 'Color', c_line, 'LineWidth', 1.6);
plot(dn, xa,      '-', 'Color', c_zero, 'LineWidth', 1.4);
xline(datenum(mark_date), '--', 'Color', [0.4 0.4 0.4], 'HandleVisibility', 'off');
hold off;  style_axes(gca);  xlim([dn(1) dn(end)]);  datetick('x', 'yyyy', 'keeplimits')
set(gca, 'FontSize', fs, mult1{:})
ylabel('Inflation, % y/y', 'FontSize', fs)
legend({'10th-90th percentile', 'Median', 'Realized inflation'}, 'Location', 'northwest', 'Box', 'off', 'FontSize', fs)
if save_figs, exportgraphics(figH, fullfile(fig_dir, 'quantiles_fit_ea.png'), 'Resolution', 300); end

% Figure I: member states (3 x 7)
figI = figure('Name','I: Fitted quantiles, member states','Color','w','Position',[20 20 1150 620]);
tlI = tiledlayout(3, 7, 'TileSpacing', 'tight', 'Padding', 'compact');
yt  = datenum(datetime(2000:5:2025, 1, 1));
for i = 1:n
    nexttile; hold on
    fill([dn; flipud(dn)], [Q(:,i,1); flipud(Q(:,i,3))], c_band, 'EdgeColor','none', 'FaceAlpha', 0.6);
    plot(dn, Q(:,i,2), '-', 'Color', c_line, 'LineWidth', 1.0);
    plot(dn, x_raw(:,i), '-', 'Color', c_zero, 'LineWidth', 0.9);
    ox = x_raw(:,i) > Q(:,i,3) | x_raw(:,i) < Q(:,i,1);          % outside the 10th-90th range
    plot(dn(ox), x_raw(ox,i), 'o', 'MarkerSize', 2.5, 'MarkerFaceColor', c_dark, 'MarkerEdgeColor', 'none');
    xline(datenum(mark_date), '--', 'Color', [0.4 0.4 0.4], 'HandleVisibility', 'off');
    hold off;  style_axes(gca);  xlim([dn(1) dn(end)])
    set(gca, 'XTick', yt, 'XTickLabel', compose('''%02d', mod(2000:5:2025, 100)), 'FontSize', fs, mult1{:})
    if i <= n - 7, set(gca, 'XTickLabel', {}); end
    title(ctry{i}, 'FontSize', fs, 'FontWeight', 'normal')
    if i == 1
        hl = legend({'10th-90th percentile', 'Median', 'Realized inflation', 'Outside the 10th-90th percentile'}, ...
                    'Orientation', 'horizontal', 'Box', 'off', 'FontSize', fs);
        hl.Layout.Tile = 'south';
    end
end
ylabel(tlI, 'Inflation, % y/y', 'FontSize', fs)
if save_figs, exportgraphics(figI, fullfile(fig_dir, 'quantiles_fit_countries.png'), 'Resolution', 300); end