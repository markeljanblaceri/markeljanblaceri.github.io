%==========================================================================
% Cutting the Flow: Geopolitical Disruptions to Russian Oil Supply and the
% Tails of Euro Area Inflation
%
% Markeljan Blaceri, University of Padova
%
% Replication files -- exposure to Russian oil and gas
%==========================================================================
% Run after QFAVAR_main.m (full sample). Builds the pre-war exposure measure
% of the paper and relates it to the country responses.
%
%   Exposure_i = 100 * ( w_oil_i * dep_oil_i + w_gas_i * dep_gas_i )
%
%   w_oil : HICP weight of liquid fuels (CP0453) + fuels for personal
%           transport (CP0722), per mille / 1000
%   w_gas : HICP weight of gas (CP0452), per mille / 1000
%   dep_* : share of Russia in net imports by country of origin
%           (Eurostat nrg_ind_idooil, nrg_ind_idogas), percent / 100
%
% Exposure is in percent of the consumer basket. Origin-based import shares
% trace intra-EU flows back to the supplier (Russian gas reaching Italy
% through Austria is attributed to Russia, not Austria). All components
% refer to 2020, the last year for which gas import shares by country of
% origin are available.
%
% Input  : 'Exposure Data.xlsx' (folder 'Additional data'), sheets 'CP0452',
%          'CP0453', 'CP0722', 'Russian oil dep', 'Russian gas dep' (rows =
%          years, first column 'year', one column per country; ':' = missing)
% Output : output/Exposure_origin.xlsx  exposure by member state (read by
%                                        counterfactual_outcome.m)
%          output/Exposure_slopes.xlsx  cross-country slopes (figure notes)
% Figures:
%   1  Exposure over time by member state (3 x 7): oil and gas components
%   2  Impact response of upside risk vs exposure, member states grouped by
%      the sign of the response (68% band above, below, or including zero)
%   3  Peak responses of the 10th, 50th, and 90th percentiles vs exposure
% The console reports the slopes (draw by draw), OLS slopes, robust (HC1)
% p-values, and R2 used in the figure notes.
%
% Helper functions (read_years, style_axes) are in 'Additional functions'.
%==========================================================================

clear; clc; close all;
addpath('Additional data'); addpath('Additional functions');
addpath('functions'); addpath('data');

%---------------------------| USER INPUT |---------------------------------
exp_file   = 'Exposure Data.xlsx';
measure    = 'oil_gas';   % 'oil_gas' (baseline) or 'oil' (oil only, fuel-specific weight)
year_w     = 2020;        % year of the HICP weights
year_oil   = 2020;        % year of the oil dependency (pre-war)
year_gas   = 2020;        % year of the gas dependency (last available)
tp_var     = 'exposure';  % Figure 1: 'exposure' (oil and gas components) or 'share' (Russian import shares)
tp_same_y  = false;       % Figure 1: true = same y-axis in all panels
res_file   = fullfile('output','QFAVAR_russia.mat');
resp_units = 'pp';        % 'pp' or 'std'
bands      = [16 84];
exclude    = {};          % countries to drop from the scatters
peak_hor   = 0:23;        % horizons searched for the peak response
peak_type  = 'max';       % 'max' or 'absmax'
group_lines  = true;      % Figure 2: fitted line within each group (groups with >= 4 countries)
overall_line = false;     % Figure 2: fitted line through all countries
save_figs    = false;     % true = export the figures to fig_dir
fig_dir      = fullfile('output','figures');
%--------------------------------------------------------------------------

% Colours as in the other figures: light blue main colour; dark navy and gray only
% where series or groups must be told apart (see legends)
c_line = [0.13 0.47 0.80]; c_dark = [0.05 0.20 0.50]; c_gray = [0.55 0.55 0.55]; c_zero = [0 0 0];
fs     = 10;                                                    % font size for all text
mult1  = {'TitleFontSizeMultiplier', 1, 'LabelFontSizeMultiplier', 1};   % no automatic enlargement
if save_figs && ~exist(fig_dir, 'dir'), mkdir(fig_dir); end

%% ======| Read data
W2 = read_years(exp_file, 'CP0452');
W3 = read_years(exp_file, 'CP0453');
W7 = read_years(exp_file, 'CP0722');
DO = read_years(exp_file, 'Russian oil dep');
DG = read_years(exp_file, 'Russian gas dep');
countries = W2.names;
for S = {W3, W7, DO, DG}
    assert(isequal(S{1}.names, countries), 'Country columns differ across sheets.');
end
pick = @(S, y) S.X(S.year == y, :);          % one year: 1 x nC

w_oil   = (pick(W3, year_w) + pick(W7, year_w)) / 1000;
w_gas   =  pick(W2, year_w) / 1000;
dep_oil =  pick(DO, year_oil) / 100;
dep_gas =  pick(DG, year_gas) / 100;

% Missing gas dependency: no Russian gas imports recorded -> 0 (reported)
mg = isnan(dep_gas);
if any(mg), fprintf('Gas dependency missing, set to 0: %s\n', strjoin(countries(mg), ', ')); end
dep_gas(mg) = 0;
mo = isnan(dep_oil);
if any(mo), warning('Oil dependency missing (left as NaN): %s', strjoin(countries(mo), ', ')); end

E_oil = 100 * w_oil .* dep_oil;
E_gas = 100 * w_gas .* dep_gas;
switch measure
    case 'oil_gas', E = E_oil + E_gas;  xlab = 'Exposure to Russian oil and gas (pre-war)';
    case 'oil',     E = E_oil;          xlab = 'Exposure to Russian oil (pre-war)';
    otherwise, error('measure must be ''oil_gas'' or ''oil''.');
end

ExpTbl = table(round(100*dep_oil',1), round(100*dep_gas',1), round(1000*w_oil',1), round(1000*w_gas',1), ...
               round(E_oil',2), round(E_gas',2), round((E_oil+E_gas)',2), 'RowNames', countries(:), ...
               'VariableNames', {'OilDep_pct','GasDep_pct','wOil_permille','wGas_permille','E_oil','E_gas','E_total'});
[~, o] = sort(ExpTbl.E_total, 'descend');
fprintf('\nPre-war exposure (percent of the consumer basket), oil %d, gas %d, weights %d:\n', year_oil, year_gas, year_w);
disp(ExpTbl(o,:))
if ~exist('output','dir'), mkdir('output'); end
writetable(ExpTbl, fullfile('output','Exposure_origin.xlsx'), 'WriteRowNames', true);

%% ======| Figure 1: exposure over time, by member state (3 x 7)
yrs  = intersect(DO.year(:)', W3.year(:)');                    % years with oil data and weights
Eo_t = nan(numel(yrs), numel(countries));  Eg_t = Eo_t;  So_t = Eo_t;  Sg_t = Eo_t;
for j = 1:numel(yrs)
    y = yrs(j);
    So_t(j,:) = pick(DO, y);
    if any(DG.year == y), Sg_t(j,:) = pick(DG, y); end
    Eo_t(j,:) = 100 * (pick(W3,y) + pick(W7,y))/1000 .* So_t(j,:)/100;
    Eg_t(j,:) = 100 *  pick(W2,y)/1000              .* Sg_t(j,:)/100;
end
switch tp_var
    case 'exposure', L1 = Eo_t; L2 = Eg_t; ylab_tp = 'Exposure (% of basket)';
                     llab = {'Oil', 'Gas'};
    case 'share',    L1 = So_t; L2 = Sg_t; ylab_tp = 'Russian share of imports (%)';
                     llab = {'Oil and petroleum products', 'Natural gas'};
end
[~, ordh] = sort(countries(:));
nC = numel(countries);

fig1 = figure('Color','w','Position',[30 60 1150 600]);
tl1 = tiledlayout(3, 7, 'TileSpacing','tight', 'Padding','compact');
ax1 = gobjects(nC,1);
for k = 1:nC
    i = ordh(k);
    ax1(k) = nexttile; hold on
    xline(2022, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 0.8, 'HandleVisibility','off');   % invasion
    h1 = plot(yrs, L1(:,i), '-o', 'Color', c_line, 'LineWidth', 1.6, 'MarkerSize', 4, 'MarkerFaceColor', c_line);
    h2 = plot(yrs, L2(:,i), '-s', 'Color', c_dark, 'LineWidth', 1.6, 'MarkerSize', 4, 'MarkerFaceColor', c_dark);
    hold off; style_axes(ax1(k))
    xlim([yrs(1)-0.5 yrs(end)+0.5]);
    xt = yrs(1):4:yrs(end);                                    % ticks every 4 years
    set(ax1(k), 'XTick', xt, 'XTickLabel', compose('%d', xt), 'FontSize', fs, ...
        'TitleFontSizeMultiplier', 1, 'LabelFontSizeMultiplier', 1)   % full year format
    title(countries{i}, 'FontSize', fs, 'FontWeight', 'normal')     % after the axes font is set
    yl = ylim(ax1(k));  ylim(ax1(k), [0 max(yl(2), 1e-6)]);
    if k <= nC - 7, set(ax1(k), 'XTickLabel', {}); end         % year labels on the bottom row only
    if k == 1
        lg = legend([h1 h2], llab, 'Orientation','horizontal', 'Box','off', 'FontSize', fs);
        lg.Layout.Tile = 'south';
    end
end
ylabel(tl1, ylab_tp, 'FontSize', fs)                           % one y-label for the whole figure
if tp_same_y, linkaxes(ax1, 'y'); end
if save_figs, exportgraphics(fig1, fullfile(fig_dir, 'exposure.png'), 'Resolution', 300); end

%% ======| QFAVAR responses
load(res_file, 'yirf_save','quant','n','r','nq','names','gpr_shock','nhor');
vars_in = who('-file', res_file);
if ismember('sample_end', vars_in), load(res_file, 'sample_end'); else, sample_end = []; end
ctry = erase(names(:)', 'HICP.');
sd_c = std(load_data(0, r, 1, 0, quant, 0, sample_end));

[~, ie, iq] = intersect(countries, ctry, 'stable');
miss = setdiff(ctry, countries);
if ~isempty(miss), warning('No exposure data for: %s', strjoin(miss, ', ')); end
xe  = E(ie)';  lab = ctry(iq);
ok  = ~isnan(xe) & ~ismember(lab(:), exclude);
xe  = xe(ok);  lab = lab(ok);  iqk = iq(ok);
nc  = numel(xe);  Xr = [ones(nc,1) xe];

%% ======| Figure 2: impact upside risk vs exposure
Yh = squeeze(yirf_save(1,:,gpr_shock,:));                         % (n*nq, draws)
if strcmp(resp_units,'pp'), Yh = Yh .* repmat(sd_c, 1, nq)'; end
UP  = Yh(2*n+1:3*n,:) - Yh(n+1:2*n,:);
UPm = UP(iqk,:);
ym  = median(UPm,2);  lo = prctile(UPm,bands(1),2);  hi = prctile(UPm,bands(2),2);
B   = Xr \ UPm;  slope = B(2,:);  b = Xr \ ym;
Res = cell(0, 5);                                                  % estimation results
Res(end+1,:) = {'Upside risk (impact)', median(slope), prctile(slope,16), prctile(slope,84), mean(slope > 0)};
fprintf('\n--- Impact upside risk on exposure (%s), %d countries ---\n', measure, nc);
fprintf('Slope across draws: median %.3f, 68%% [%.3f, %.3f], P(slope > 0) = %.2f\n', ...
        median(slope), prctile(slope,16), prctile(slope,84), mean(slope > 0));

% Groups, based on the 68% band of the impact upside-risk response
grp = 3*ones(nc,1);                      % 3 = insignificant
grp(lo > 0) = 1;                         % 1 = increase in upside risk
grp(hi < 0) = 2;                         % 2 = decrease in upside risk
gnames = {'Increase in upside risk','Decrease in upside risk','Insignificant'};
gcols  = [c_line; c_dark; c_gray];          % increase, decrease, insignificant
for gg = 1:3
    fprintf('%-25s (%d): %s\n', gnames{gg}, sum(grp==gg), strjoin(lab(grp==gg), ', '));
end

fig2 = figure('Color','w','Position',[100 100 820 600]); hold on
hleg = gobjects(0); lleg = {};
for gg = 1:3
    kk = (grp == gg);
    if ~any(kk), continue; end
    h = errorbar(xe(kk), ym(kk), ym(kk)-lo(kk), hi(kk)-ym(kk), 'o', 'Color', gcols(gg,:), ...
                 'MarkerFaceColor', gcols(gg,:), 'MarkerEdgeColor', gcols(gg,:), 'CapSize', 0, 'LineWidth', 1);
    hleg(end+1) = h;  lleg{end+1} = sprintf('%s (%d)', gnames{gg}, sum(kk)); %#ok<SAGROW>
    if group_lines && sum(kk) >= 4                              % descriptive fit within the group
        bg = [ones(sum(kk),1) xe(kk)] \ ym(kk);
        xg = linspace(min(xe(kk)), max(xe(kk)), 20)';
        plot(xg, bg(1) + bg(2)*xg, '--', 'Color', gcols(gg,:), 'LineWidth', 1.2, 'HandleVisibility','off');
    end
end
xx = linspace(min(xe), max(xe), 50)';
if overall_line
    hleg(end+1) = plot(xx, b(1) + b(2)*xx, '-', 'Color', c_zero, 'LineWidth', 1.4);
    lleg{end+1} = 'All countries (fit through medians)';
end
text(xe, ym, strcat({'  '}, lab(:)), 'FontSize', fs, 'VerticalAlignment', 'bottom');
yline(0, '-', 'Color', c_zero, 'LineWidth', 0.6, 'HandleVisibility','off');
hold off; style_axes(gca)
xl = xlim; xlim([min(0, xl(1)) max(xl(2), max(xe) * 1.15)])   % room for the label of the most exposed country
set(gca, 'FontSize', fs, mult1{:})
xlabel(xlab, 'FontSize', fs)
if strcmp(resp_units,'pp'), ylabel('Impact response of upside risk (pp)', 'FontSize', fs)
else,                       ylabel('Impact response of upside risk (SD)', 'FontSize', fs); end
% (slope reported in the console, not on the figure)
legend(hleg, lleg, 'Location','southoutside', 'Orientation','horizontal', 'Box','off', 'FontSize', fs);
if save_figs, exportgraphics(fig2, fullfile(fig_dir, 'exposure_urisk.png'), 'Resolution', 300); end

%% ======| Figure 3: peak percentile responses vs exposure
peak_hor = peak_hor(peak_hor <= nhor-1);
Yall = reshape(yirf_save(peak_hor+1, :, gpr_shock, :), numel(peak_hor), n*nq, []);
if strcmp(resp_units,'pp'), Yall = Yall .* repmat(sd_c, 1, nq); end
qtit = {'10th percentile','50th percentile','90th percentile'};
qcol = repmat(c_line, 3, 1);                % same colour for the three percentiles
Hpk  = zeros(nc, nq);

fig3 = figure('Color','w','Position',[60 120 1500 470]);
tl = tiledlayout(1, 3, 'TileSpacing','compact', 'Padding','compact');
fprintf('\n--- Peak percentile responses on exposure (%s), %d countries ---\n', measure, nc);
for q = 1:nq
    Yq  = Yall(:, (q-1)*n+1:q*n, :);
    med = median(Yq, 3);
    if strcmp(peak_type,'absmax'), [~, hs] = max(abs(med), [], 1); else, [~, hs] = max(med, [], 1); end
    P = zeros(n, size(Yq,3));
    for i = 1:n, P(i,:) = reshape(Yq(hs(i), i, :), 1, []); end
    P = P(iqk,:);  Hpk(:,q) = peak_hor(hs(iqk))';
    pm = median(P,2);  plo = prctile(P,bands(1),2);  phi = prctile(P,bands(2),2);
    Bq = Xr \ P;  sq = Bq(2,:);  bq = Xr \ pm;
    e_ols = pm - Xr*bq;
    R2    = 1 - sum(e_ols.^2) / sum((pm - mean(pm)).^2);
    V_hc1 = (Xr'*Xr) \ (Xr' * (Xr .* e_ols.^2)) / (Xr'*Xr) * nc/(nc-2);
    p_hc1 = 2 * (1 - tcdf(abs(bq(2) / sqrt(V_hc1(2,2))), nc-2));
    fprintf('%-16s OLS slope %.3f, HC1 p-value %.3f, R2 %.2f\n', qtit{q}, bq(2), p_hc1, R2);
    fprintf('%-16s slope: median %.3f, 68%% [%.3f, %.3f], P(slope > 0) = %.2f\n', ...
            qtit{q}, median(sq), prctile(sq,16), prctile(sq,84), mean(sq > 0));
    Res(end+1,:) = {['Peak, ' qtit{q}], median(sq), prctile(sq,16), prctile(sq,84), mean(sq > 0)}; %#ok<SAGROW>
    nexttile; hold on
    errorbar(xe, pm, pm-plo, phi-pm, 'o', 'Color', qcol(q,:), 'MarkerFaceColor', qcol(q,:), ...
             'MarkerEdgeColor', qcol(q,:), 'CapSize', 0, 'LineWidth', 1);
    plot(xx, bq(1) + bq(2)*xx, '--', 'Color', c_zero, 'LineWidth', 1.2);
    text(xe, pm, strcat({'  '}, lab(:)), 'FontSize', fs, 'VerticalAlignment', 'bottom');
    yline(0, '-', 'Color', c_zero, 'LineWidth', 0.6);
    hold off; style_axes(gca)
    xl = xlim; xlim([min(0, xl(1)) max(xl(2), max(xe) * 1.25)])                       % room for the label of the most exposed country
    set(gca, 'FontSize', fs, 'TitleFontSizeMultiplier', 1, 'LabelFontSizeMultiplier', 1)  % no automatic enlargement
    title(qtit{q}, 'FontSize', fs, 'FontWeight', 'normal')
    xlabel(xlab, 'FontSize', fs)                                                         % x-label on every panel
    if q == 1
        if strcmp(resp_units,'pp'), ylabel('Peak response (pp)', 'FontSize', fs)
        else,                       ylabel('Peak response (SD)', 'FontSize', fs); end
    end
end
if save_figs, exportgraphics(fig3, fullfile(fig_dir, 'exposure_percentiles.png'), 'Resolution', 300); end
fprintf('Peak horizon of the posterior median response (0 = impact):\n');
disp(array2table(Hpk, 'RowNames', lab(:), 'VariableNames', {'h_Q10','h_Q50','h_Q90'}))

%% ======| Estimation results (for the figure notes; not shown on the figures)
Res = cell2table(Res, 'VariableNames', {'Response','Slope_median','Slope_p16','Slope_p84','P_positive'});
fprintf('\n=== Estimation results: cross-country slope on exposure (%s), %d countries ===\n', measure, nc);
disp(Res)
writetable(Res, fullfile('output','Exposure_slopes.xlsx'), 'Sheet', measure);
fprintf(['Note text: The slope of the fit, computed draw by draw, has a posterior median of %.3f, %.3f, and %.3f ' ...
         'for the 10th, 50th, and 90th percentiles, with posterior probabilities of a positive slope of %.2f, %.2f, and %.2f.\n'], ...
        Res.Slope_median(2:4), Res.P_positive(2:4));