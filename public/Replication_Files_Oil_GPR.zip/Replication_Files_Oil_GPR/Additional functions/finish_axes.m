function finish_axes(x, ttl, ylab, show_legend, hh, slabels, c_zero)
plot(x, zeros(size(x)), '--', 'Color', c_zero, 'LineWidth', 1, 'HandleVisibility','off');
hold off
style_axes(gca); xlim([x(1) x(end)])
title(ttl, 'FontSize', 11, 'FontWeight', 'bold', 'Interpreter', 'none')
if ~isempty(ylab), ylabel(ylab); end
if show_legend                                   % one legend below the whole figure
    lg = legend(hh, slabels, 'Orientation','horizontal', 'Box','off');
    lg.Layout.Tile = 'south';
end
end