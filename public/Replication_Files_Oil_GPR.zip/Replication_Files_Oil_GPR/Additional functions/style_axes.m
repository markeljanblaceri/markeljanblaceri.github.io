function style_axes(ax)
% STYLE_AXES  Common axes style for all figures of the paper:
% box on, solid light-gray grid behind the data, gray axes, ticks inside.
if nargin < 1, ax = gca; end
grid(ax, 'on'); box(ax, 'on')
set(ax, 'GridLineStyle', '-', 'GridColor', [0.5 0.5 0.5], 'GridAlpha', 0.25, ...
    'Layer', 'bottom', 'XColor', [0.3 0.3 0.3], 'YColor', [0.3 0.3 0.3], 'TickDir', 'in')
end