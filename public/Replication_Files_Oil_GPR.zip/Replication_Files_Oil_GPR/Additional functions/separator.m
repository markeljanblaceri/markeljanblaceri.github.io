function separator(tile_col, n_rows)
% Vertical dashed line spanning all rows in the given tile column
nexttile(tile_col, [n_rows, 1])
plot([0.5 0.5], [0 1], '--', 'Color', [0.4 0.4 0.4], 'LineWidth', 1.2)
xlim([0 1]); ylim([0 1]); axis off
end