function tbl = readSheet(file, sheet)
    opts = detectImportOptions(file, 'Sheet', sheet, ...
                               'VariableNamingRule', 'preserve');
    vars = opts.VariableNames(2:end);                  % all country columns
    opts = setvartype(opts, vars, 'double');
    opts = setvaropts(opts, vars, 'TreatAsMissing', {'NA'});
    tbl  = readtable(file, opts);
    if strcmp(opts.VariableNames{1}, 'month')
        tbl.month = datetime(tbl.month);               % ensure datetime
    end
end