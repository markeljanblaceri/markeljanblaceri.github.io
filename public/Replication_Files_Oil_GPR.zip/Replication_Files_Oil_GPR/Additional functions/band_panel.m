function band_panel(h, D, bands, band_col, line_col, zero_col, lw, ms)
% D: (horizon, draws). Shaded credible band, dashed zero line,
% posterior mean with filled circles. ms = marker size (default 4).
if nargin < 8, ms = 4; end
lo = prctile(D, bands(1), 2)';  hi = prctile(D, bands(2), 2)';
hold on
fill([h, fliplr(h)], [lo, fliplr(hi)], band_col, 'EdgeColor', 'none', ...
    'FaceAlpha', 0.40, 'HandleVisibility', 'off')
plot(h, zeros(1, numel(h)), '--', 'Color', zero_col, 'LineWidth', 1, 'HandleVisibility', 'off')
plot(h, mean(D, 2)', '-o', 'Color', line_col, 'LineWidth', lw, ...
    'MarkerSize', ms, 'MarkerFaceColor', line_col, 'MarkerEdgeColor', 'none')
hold off
style_axes(gca)
xlim([h(1) h(end)])
end