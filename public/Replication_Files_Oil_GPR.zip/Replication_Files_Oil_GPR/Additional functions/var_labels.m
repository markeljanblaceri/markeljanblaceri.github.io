function [g1, g2] = var_labels(nm, nice, lab2)
% One-line and two-line labels for global variables
g1 = nm;  g2 = cell(1, numel(nm));
for j = 1:numel(nm)
    if isfield(lab2, nm{j}), g2{j} = lab2.(nm{j}); else, g2{j} = {nm{j}, ''}; end
    if isfield(nice, nm{j}), g1{j} = nice.(nm{j}); end
end
end