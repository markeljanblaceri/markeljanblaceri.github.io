function band(x, D, bands, col)
lo = prctile(D, bands(1), 2);  hi = prctile(D, bands(2), 2);
fill([x; flipud(x)], [lo; flipud(hi)], col, 'EdgeColor','none', 'FaceAlpha', 0.35, 'HandleVisibility','off');
end