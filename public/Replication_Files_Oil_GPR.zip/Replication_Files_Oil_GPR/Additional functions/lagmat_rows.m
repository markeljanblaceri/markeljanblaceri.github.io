function X = lagmat_rows(y, py, m)
[T, N] = size(y);  X = zeros(T-m, N*py);
for l = 1:py, X(:, (l-1)*N+1:l*N) = y(m+1-l:T-l, :); end
end