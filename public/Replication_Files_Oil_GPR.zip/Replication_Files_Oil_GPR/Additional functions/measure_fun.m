function f = measure_fun(m)
% Maps fitted quantiles Q (T x n x 3: 10th, 50th, 90th) to the chosen measure (T x n)
switch lower(m)
    case 'q10',         f = @(Q) Q(:,:,1);
    case 'q50',         f = @(Q) Q(:,:,2);
    case 'q90',         f = @(Q) Q(:,:,3);
    case 'upside',      f = @(Q) Q(:,:,3) - Q(:,:,2);
    case 'downside',    f = @(Q) Q(:,:,2) - Q(:,:,1);
    case 'uncertainty', f = @(Q) Q(:,:,3) - Q(:,:,1);
    otherwise, error('show_meas must be q10, q50, q90, upside, downside or uncertainty.');
end
end