function S = read_years(file, sheet)
% Sheet with first column 'year' and one column per country; ':' -> NaN
T = readtable(file, 'Sheet', sheet, 'VariableNamingRule', 'preserve');
S.names = T.Properties.VariableNames(2:end);
S.year  = T{:,1};
S.X     = nan(height(T), numel(S.names));
for j = 1:numel(S.names)
    v = T{:, j+1};
    if iscell(v), v = str2double(v); end          % ':' and blanks become NaN
    S.X(:,j) = v;
end
keep = ~isnan(S.year);  S.year = S.year(keep);  S.X = S.X(keep,:);
end