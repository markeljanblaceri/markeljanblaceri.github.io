function band_plot(h, D, bands, col)
% D: (horizon, draws). Median line with credible band.
lo = prctile(D,bands(1),2); hi = prctile(D,bands(2),2);
fill([h; flipud(h)], [lo; flipud(hi)], col, 'FaceAlpha',0.2, ...
    'EdgeColor','none', 'HandleVisibility','off'); hold on
plot(h, median(D,2), 'Color', col, 'LineWidth', 1.5);
yline(0, 'k', 'HandleVisibility','off'); grid on; xlim([h(1) h(end)]);
end