function R = varx_irf(A, bc, dl, nl, nhor, py, q)
% Response of z to a shock of size dl (in eps units), standardized units
ny = size(A,1);  R = zeros(nhor, ny);
for h = 1:nhor
    if h-1 <= q
        R(h,:) = (bc(:,2*(h-1)+1)*dl + bc(:,2*(h-1)+2)*nl(dl))';
    end
    for l = 1:py
        if h-l >= 1, R(h,:) = R(h,:) + (A(:,(l-1)*ny+1:l*ny) * R(h-l,:)')'; end
    end
end
end