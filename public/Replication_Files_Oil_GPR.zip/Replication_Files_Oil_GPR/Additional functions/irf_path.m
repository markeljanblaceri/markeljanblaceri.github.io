function S = irf_path(A, B0, js, p, H)
% Responses of the state vector to structural shock js, unit impact on itself
N = size(B0, 1);  S = zeros(H, N);
S(1,:) = B0(:, js)' / B0(js, js);
for h = 2:H
    s = zeros(1, N);
    for l = 1:min(p, h-1), s = s + (A(:, (l-1)*N+1:l*N) * S(h-l,:)')'; end
    S(h,:) = s;
end
end