function band_line(h, D, bands, col)
% D: (horizon, draws). Shaded band + median line.
lo = prctile(D, bands(1), 2);  hi = prctile(D, bands(2), 2);
hold on
fill([h; flipud(h)], [lo; flipud(hi)], col, 'FaceAlpha', 0.12, 'EdgeColor','none', 'HandleVisibility','off');
plot(h, median(D, 2), 'Color', col, 'LineWidth', 1.8);
end