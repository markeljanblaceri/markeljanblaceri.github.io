function X = lagmat(Z, p)
[T, N] = size(Z);  X = zeros(T-p, N*p);
for l = 1:p, X(:, (l-1)*N+1:l*N) = Z(p+1-l:T-l, :); end
end