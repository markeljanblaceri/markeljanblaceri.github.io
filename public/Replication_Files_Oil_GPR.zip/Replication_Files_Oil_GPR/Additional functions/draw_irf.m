function h = draw_irf(x, D, bands, s, col, c_band)
% First size: filled band + solid line with markers. Others: dashed band edges + solid line.
lo = prctile(D, bands(1), 2);  hi = prctile(D, bands(2), 2);  mn = mean(D, 2);
hold on
if s == 1
    fill([x; flipud(x)], [lo; flipud(hi)], c_band, 'EdgeColor','none', 'FaceAlpha', 0.40, 'HandleVisibility','off');
    h = plot(x, mn, '-o', 'Color', col, 'LineWidth', 2.0, 'MarkerSize', 3.5, 'MarkerFaceColor', col, 'MarkerEdgeColor','none');
else
    plot(x, lo, '--', 'Color', col, 'LineWidth', 0.8, 'HandleVisibility','off');
    plot(x, hi, '--', 'Color', col, 'LineWidth', 0.8, 'HandleVisibility','off');
    h = plot(x, mn, '-', 'Color', col, 'LineWidth', 1.8);
end
end