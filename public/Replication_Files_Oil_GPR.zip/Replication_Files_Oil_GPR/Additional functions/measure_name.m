function s = measure_name(m)
switch lower(m)
    case 'q10',      s = '10th percentile';          case 'q50',      s = '50th percentile';
    case 'q90',      s = '90th percentile';          case 'upside',   s = 'Upside risk (Q90 - Q50)';
    case 'downside', s = 'Downside risk (Q50 - Q10)'; case 'uncertainty', s = 'Uncertainty (Q90 - Q10)';
end
end