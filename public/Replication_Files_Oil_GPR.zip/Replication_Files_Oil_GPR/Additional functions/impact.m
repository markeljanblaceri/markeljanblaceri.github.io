function B0 = impact(Om, perm_idx)
% Cholesky impact matrix in the identification ordering [g, F], mapped back to [F, g]
N  = size(Om, 1);
Bp = chol(Om(perm_idx, perm_idx), 'lower');
B0 = zeros(N);  B0(perm_idx, perm_idx) = Bp;
end
