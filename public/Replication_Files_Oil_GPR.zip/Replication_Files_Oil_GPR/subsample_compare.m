%==========================================================================
% Cutting the Flow: Geopolitical Disruptions to Russian Oil Supply and the
% Tails of Euro Area Inflation
%
% Markeljan Blaceri, University of Padova
%
% Replication files -- estimates on samples ending before the invasion
%==========================================================================
% Run after main.m has been run three times, with sample_end = [],
% 2021, and 2019 (files output/QFAVAR_russia.mat, QFAVAR_russia_2021.mat,
% QFAVAR_russia_2019.mat). Compares the responses to the disruption shock
% across the three samples.
%
% Shock size (shock_mode):
%   'common' : the same shock in index points in every sample (baseline:
%              60 points, one standard deviation of the index in the full
%              sample, as in the main results)
%   'own'    : one standard deviation of the index in each sample
% Responses are de-standardized with the standard deviations of each sample.
%
% Style: the full sample is drawn with a shaded band and a line with markers;
% the other samples with dashed band edges and a solid line (see legend).
%
% Figures:
%   A  Euro area inflation percentiles (10th, 50th, 90th)
%   B  Global factors, including the disruption index
%   C  Euro area upside and downside risk
%   D  Upside risk on impact by member state
% The console reports the impact responses in each sample.
%
% Helper functions (draw_irf, finish_axes, style_axes) are in
% 'Additional functions'.
%==========================================================================

clear; clc; close all;
addpath('functions'); addpath('data'); addpath('Additional functions')

%---------------------------| USER INPUT |---------------------------------
files      = {fullfile('output','QFAVAR_russia.mat'), ...
              fullfile('output','QFAVAR_russia_2021.mat'), ...
              fullfile('output','QFAVAR_russia_2019.mat')};
slabels    = {'Full sample', 'Sample ends 2021', 'Sample ends 2019'};
shock_mode = 'common';       % 'common' (shock_pts index points) or 'own' (one SD in each sample)
shock_pts  = 60;             % common shock size, in index points (used if shock_mode = 'common')
bands      = [16 84];        % 68% credible bands
fac_scale  = 'ea_avg';       % 'ea_avg' or 'austria'
save_figs  = false;          % true = export the figures to fig_dir
fig_dir    = fullfile('output','figures');
%--------------------------------------------------------------------------

% Colours: full sample light blue (+ lighter band); the other samples dark
% navy, dark gray, black (one per sample, see legend)
scols  = [0.13 0.47 0.80; 0.05 0.20 0.50; 0.45 0.45 0.45; 0.00 0.00 0.00];
c_band = [0.55 0.76 0.95];
c_zero = [0 0 0];
fs     = 10;                                                    % font size
if save_figs && ~exist(fig_dir, 'dir'), mkdir(fig_dir); end

ns   = numel(files);
keep = true(1, ns);
for s = 1:ns
    if ~isfile(files{s})
        warning('File not found, skipped: %s', files{s}); keep(s) = false; continue
    end
    M = load(files{s}, 'firf_save','yirf_save','quant','nhor','n','ng','r','nq', ...
                       'names','namesg','gpr_shock');
    vars_in = who('-file', files{s});
    if ismember('sample_end', vars_in), load(files{s}, 'sample_end'); else, sample_end = []; end

    % Standard deviations of the raw data over THIS sample
    [x_raw,~,~,~,~,g_raw,~,dates_s] = load_data(0, M.r, 1, 0, M.quant, 0, sample_end);
    sd_c = std(x_raw);  sd_g = std(g_raw);
    switch fac_scale
        case 'ea_avg',  sd_f = mean(sd_c);
        case 'austria', sd_f = sd_c(1);
    end
    switch shock_mode
        case 'common', sc = shock_pts / sd_g(1);       % shock of shock_pts index points
        case 'own',    sc = 1;                         % one SD of the index in this sample
    end

    Y  = squeeze(M.yirf_save(:,:,M.gpr_shock,:)) .* repmat(sd_c, 1, M.nq) * sc;   % pp
    St = squeeze(M.firf_save(:,:,M.gpr_shock,:)) * sc;
    R(s).fac  = St(:, 1:M.r*M.nq, :) * sd_f;                                   %#ok<SAGROW> pp
    R(s).glob = St(:, M.r*M.nq+1:end, :) .* reshape(sd_g, 1, [], 1);           % own units
    n = M.n;
    R(s).UPc  = squeeze(Y(1, 2*n+1:3*n, :) - Y(1, n+1:2*n, :));                % country upside, impact: (n, draws)
    R(s).UP   = squeeze(R(s).fac(:,3,:) - R(s).fac(:,2,:));                     % EA upside: (h, draws)
    R(s).DN   = squeeze(R(s).fac(:,2,:) - R(s).fac(:,1,:));                     % EA downside
    R(s).nhor = M.nhor;
    fprintf('%-18s %s-%s | index SD = %5.1f pts | shock = %.1f pts = %.2f SD\n', ...
            slabels{s}, dates_s{1}, dates_s{end}, sd_g(1), sc*sd_g(1), sc);
end
R = R(keep);  slabels = slabels(keep);  scols = scols(find(keep), :);  ns = numel(R);
ctry   = erase(M.names(:)', 'HICP.');
namesg = M.namesg;  ng = M.ng;  nhor = min([R.nhor]);
hz     = (1:nhor)';                                   % 1 = impact

nice = struct('russia_gpr','Disruption index', 'oil_inflation','Oil price inflation', ...
              'gas_inflation','Gas price inflation', 'ciss','CISS', 'gscpi','GSCPI', ...
              'urate','Unemployment rate', 'shadow_rate','Shadow rate');
units = struct('russia_gpr','Index points', 'ciss','Index (0-1)', 'gscpi','Std. dev.');
gnames = namesg;
for j = 1:ng, if isfield(nice, namesg{j}), gnames{j} = nice.(namesg{j}); end, end

%% Figure A: quantile factors
figA = figure('Name','A: Quantile factors by sample','Color','w','Position',[50 100 1100 340]);
tiledlayout(1, 3, 'TileSpacing','compact', 'Padding','compact');
qn = {'10th Percentile','50th Percentile','90th Percentile'};
for q = 1:3
    nexttile
    hh = gobjects(ns,1);
    for s = 1:ns, hh(s) = draw_irf(hz, squeeze(R(s).fac(1:nhor,q,:)), bands, s, scols(s,:), c_band); end
    finish_axes(hz, qn{q}, 'Percentage points', q == 1, hh, slabels, c_zero)
end
if save_figs, exportgraphics(figA, fullfile(fig_dir, 'subsample_percentiles.png'), 'Resolution', 300); end

%% Figure B: global variables
figB = figure('Name','B: Global variables by sample','Color','w','Position',[50 100 1100 520]);
tiledlayout(2, ceil(ng/2), 'TileSpacing','compact', 'Padding','compact');
for j = 1:ng
    nexttile
    hh = gobjects(ns,1);
    for s = 1:ns, hh(s) = draw_irf(hz, squeeze(R(s).glob(1:nhor,j,:)), bands, s, scols(s,:), c_band); end
    if isfield(units, namesg{j}), yl = units.(namesg{j}); else, yl = 'Percentage points'; end
    finish_axes(hz, gnames{j}, yl, j == 1, hh, slabels, c_zero)
end
if save_figs, exportgraphics(figB, fullfile(fig_dir, 'subsample_globals.png'), 'Resolution', 300); end

%% Figure C: EA upside and downside risk
figC = figure('Name','C: EA tail risks by sample','Color','w','Position',[50 100 900 360]);
tiledlayout(1, 2, 'TileSpacing','compact', 'Padding','compact');
nexttile
hh = gobjects(ns,1);
for s = 1:ns, hh(s) = draw_irf(hz, R(s).UP(1:nhor,:), bands, s, scols(s,:), c_band); end
finish_axes(hz, 'Upside Risk', 'Percentage points', true, hh, slabels, c_zero)
nexttile
for s = 1:ns, hh(s) = draw_irf(hz, R(s).DN(1:nhor,:), bands, s, scols(s,:), c_band); end
finish_axes(hz, 'Downside Risk', 'Percentage points', false, hh, slabels, c_zero)
if save_figs, exportgraphics(figC, fullfile(fig_dir, 'subsample_risks.png'), 'Resolution', 300); end

%% Figure D: country upside risk on impact
figD = figure('Name','D: Country upside risk on impact by sample','Color','w','Position',[50 100 1200 420]);
hold on
off = linspace(-0.25, 0.25, ns);  hd = gobjects(ns,1);
for s = 1:ns
    mn = mean(R(s).UPc, 2);
    lo = prctile(R(s).UPc, bands(1), 2);  hi = prctile(R(s).UPc, bands(2), 2);
    if s == 1, mk = 'o'; else, mk = 'd'; end                 % full sample: circles; others: diamonds
    hd(s) = errorbar((1:n)' + off(s), mn, mn - lo, hi - mn, mk, 'Color', scols(s,:), ...
                     'MarkerFaceColor', scols(s,:), 'MarkerEdgeColor', 'none', 'MarkerSize', 5, ...
                     'CapSize', 0, 'LineWidth', 1);
end
hold off; style_axes(gca)
yline(0, '--', 'Color', c_zero, 'LineWidth', 1, 'HandleVisibility','off');
xlim([0.5 n + 0.5]); set(gca, 'XTick', 1:n, 'XTickLabel', ctry, 'XTickLabelRotation', 45, 'XGrid', 'off', ...
    'FontSize', fs, 'LabelFontSizeMultiplier', 1)
ylabel('Upside risk on impact (pp)', 'FontSize', fs)
legend(hd, slabels, 'Location','southoutside', 'Orientation','horizontal', 'Box','off', 'FontSize', fs);
if save_figs, exportgraphics(figD, fullfile(fig_dir, 'subsample_country_risks.png'), 'Resolution', 300); end

%% Table: impact responses (posterior mean) by sample
if strcmp(shock_mode, 'common'), stxt = sprintf('+%g point', shock_pts); else, stxt = 'one-SD (own sample)'; end
fprintf('\nImpact responses to a %s disruption shock (posterior mean, 68%% band)\n', stxt);
qtag = {'Q10','Q50','Q90'};
for s = 1:ns
    fprintf('%s\n', slabels{s});
    for q = 1:3
        D = squeeze(R(s).fac(1,q,:));
        fprintf('   Factor %-4s %7.3f  [%7.3f, %7.3f]\n', qtag{q}, mean(D), prctile(D,bands(1)), prctile(D,bands(2)));
    end
    fprintf('   Upside      %7.3f  [%7.3f, %7.3f]\n', mean(R(s).UP(1,:)), prctile(R(s).UP(1,:),bands(1)), prctile(R(s).UP(1,:),bands(2)));
    fprintf('   Downside    %7.3f  [%7.3f, %7.3f]\n', mean(R(s).DN(1,:)), prctile(R(s).DN(1,:),bands(1)), prctile(R(s).DN(1,:),bands(2)));
end