%% Cutting the Flow: Geopolitical Disruptions to Russian Oil Supply and the Tails of Euro Area Inflation
% Markeljan Blacëri
% markeljan.blaceri@phd.unipd.it

% This script estimates the model of the paper and saves the posterior draws
% and the impulse responses used by all the other scripts.
%
%   Data   : x = year-on-year HICP inflation, 21 euro area member states
%                (one common factor per quantile, r = 1)
%            g = [Russia oil supply disruption index (ordered first),
%                 oil and gas price inflation, CISS, GSCPI, unemployment
%                 rate, shadow rate]
%   Model  : quantile factor-augmented VAR, quantiles 0.1, 0.5, 0.9, p = 2,
%            horseshoe priors, estimated by MCMC
%   Shock  : recursive (Cholesky) identification on the state vector
%            ordered as [g, F], with the disruption index first

% Output : output/QFAVAR_russia.mat (full sample), or
%          output/QFAVAR_russia_<year>.mat (samples ending in December <year>)
%
% Set sample_end below: [] for the baseline (January 2000 - December 2025),
% 2021 and 2019 for the subsample estimates.
%
% Based on the code of
%      Dimitris Korobilis         and       Maximilian Schroeder
%    University of Glasgow        and   Norwegian BI Business School
% (Korobilis and Schroeder, 2025), whose functions are in the folder 'functions'.

clear all; clc; close all;

% Add path of additional folders
addpath('functions')
addpath('data')

% Model settings
r         = 1;              % Number of factors (one EA inflation factor)
p         = 2;              % Number of lags
quant     = [.1, .5, .9];   % Specify the quantiles to estimate
interX    = 0;              % Intercept in measurement equation
interF    = 0;              % Intercept in state equation
AR1x      = 0;              % Include own lag
incldg    = 1;              % Include global factors g in the measurement equation
dfm       = 0;              % 0: estimate QFAVAR; 1: estimate QDFM
standar   = 2;              % 0: no standardization; 1: standardize only x variables; 2: standardize both x and g variables
ALsampler = 1;              % Asymmetric Laplace sampler, 1: Khare and Robert (2012); 2: Kozumi and Koyabashi (2011)
var_sv    = 0;              % VAR variances, 0: constant; 1: time-varying (stochastic volatility)
nhor      = 24;             % Horizon for IRFs and FEVDs
bands     = [16 84];        % Percentiles for credible bands (68%)

% Random seed (for replication)
rng(1);

% Gibbs-related preliminaries
nsave     = 50000;          % Number of draws to store
nburn     = 2000;           % Number of draws to discard
ngibbs    = nsave + nburn;  % Number of total draws
nthin     = 50;
iter      = 20;             % Print every "iter" iteration

% Sample and output file
sample_end = [];                % [] = full sample (baseline); 2021 or 2019 (= December of that year)
% Accept a year (2021 -> Dec 2021), [year month], text ('2021-12') or datetime
if ~isempty(sample_end) && ~isdatetime(sample_end)
    if isnumeric(sample_end) && isscalar(sample_end)
        sample_end = datetime(sample_end, 12, 1);
    elseif isnumeric(sample_end) && numel(sample_end) == 2
        sample_end = datetime(sample_end(1), sample_end(2), 1);
    else
        sample_end = datetime(sample_end);
    end
end
out_dir    = 'output';
if isempty(sample_end)
    save_file = fullfile(out_dir, 'QFAVAR_russia.mat');
else
    save_file = fullfile(out_dir, sprintf('QFAVAR_russia_%d.mat', year(sample_end)));
end
if ~exist(out_dir,'dir'); mkdir(out_dir); end
%--------------------------------------------------------------------------

% LOAD DATA
[x,xlag,T,n,k,g,ng,dates,names,namesg,tcode] = load_data(standar,r,p,interF,quant,dfm,sample_end);
fprintf('Sample: %s - %s (T = %d). Results will be saved to %s\n', dates{1}, dates{end}, T, save_file);

%=========| Estimation
nq        = length(quant);  % Number of quantiles
nstate    = r*nq + ng;      % Dimension of the state vector [F, g]
gpr_shock = r*nq + 1;       % Position of the GPR index in [F, g] (first element of g)
% The next three quantities are required for the posterior of latent quantities z and w
k2_sq     = 2./(quant.*(1-quant));
k1        = (1-2*quant)./(quant.*(1-quant));
k1_sq     = k1.^2;

% Horseshoe prior for L
lambdaL   = 0.1*ones(n,r+AR1x+interX+ng,nq);     % "local" shrinkage parameters
tauL      = 0.1*ones(n,nq);                      % "global" shrinkage parameter
nuL       = 0.1*ones(n,r+AR1x+interX+ng,nq);
xiL       = 0.1*ones(n,nq);

% Horseshoe prior for Phi
lambdaPhi = 0.1*ones(nstate,k);                  % "local" shrinkage parameters
tauPhi    = 0.1*ones(nstate,1);                  % "global" shrinkage parameter
nuPhi     = 0.1*ones(nstate,k);
xiPhi     = 0.1*ones(nstate,1);

% Choose sampling algorithm for VAR parameters
est_meth = 1 + double(k>T);

% Initialize matrices
xbar      = 0*x;
Lbar      = zeros(n,r,T,nq);
Lbar2     = zeros(n*nq,ng,T);
L         = zeros(r+AR1x+interX+ng,n,nq);
Sigma     = 0.1*ones(n,nq);
z         = 0.1*ones(T,n,nq);
Phi       = 0.1*ones(k,nstate);
Omega     = 0.1*ones(1,nstate);
Omega_t   = 0.1*ones(T-p,nstate);
OMEGA     = 0.1*ones(nstate,nstate,T);
h         = 0.1*ones(T-p,nstate);
sig       = 0.1*ones(nstate,1);
F         = zeros(T,nstate);
FL        = zeros(T,n,nq);
Omegac    = zeros(nstate*p,nstate*p,T);
Phic      = [Phi(interF+1:end,:)'; eye(nstate*(p-1)) zeros(nstate*(p-1),nstate)];
Omegac(1:nstate,1:nstate,:) = repmat(diag(Omega),1,1,T);
QL        = 1*ones(r+AR1x+interX+ng,n,nq);
QPhi      = 1*ones(k,nstate);
intF      = zeros(T,nstate*p);

% Extract QFA estimates (VBQFA) on the whole inflation panel: one factor
fqfa      = zeros(T,r,nq);
disp('Extracting VBQFA factors...')
fqfa(:,1,:) = VBQFA(zscore(x),1,500,quant,0,1);
F(:,1:r*nq) = fqfa(:,:);
clc;

if AR1x == 0; ARindex = []; else, ARindex=1; end

% Storage space for Gibbs draws
F_draws     = zeros(T,r*nq,nsave/nthin);
L_draws     = zeros(r+AR1x+interX+ng,n,nq,nsave/nthin);
Phi_draws   = zeros(k,nstate,nsave/nthin);
Sigma_draws = zeros(n,nq,nsave/nthin);
OMEGA_draws = zeros(nstate,nstate,T,nsave/nthin);
z_draws     = zeros(T,n,nq,nsave/nthin);

firf_save   = zeros(nhor,nstate,nstate,nsave/nthin);   % state IRFs (GPR impact normalized to 1)
yirf_save   = zeros(nhor,n*nq,nstate,nsave/nthin);     % country-quantile IRFs (same normalization)
fevd_save   = zeros(nhor,nstate,nsave/nthin);          % share of FEV due to the GPR shock
%% ============================| START MCMC |==============================
format bank;
fprintf('Now you are running QFAVAR with MCMC')
fprintf('\n')
fprintf('Iteration 000000')
savedraw = 0; tic;
for irep = 1:(nsave+nburn)
    % Print every "iter" iterations on the screen
    if mod(irep,iter) == 0
        fprintf('%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%s%6d',8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,'Iteration ',irep)
    end
    %%%%%%%% ================================================================================================== %%%%%%%%
    %%%%%%%% =====================| QFAVAR measurement equation (Factor extraction) |========================== %%%%%%%%
    Lc    = zeros(n*nq,nstate,T);
    Lfull = zeros(n*nq+ng,nstate,T);
    for q = 1:nq
        x_tilde = 0*x;
        Fq = F(:,(q-1)*r+1:q*r);
        for i = 1:n  % equation-by-equation estimation
            %% All countries load on the single factor
            F_all = [ones(T,(interX==1)), xlag(:,ARindex*i), g, Fq];
            select = [1:interX+AR1x + incldg*ng, interX+AR1x+ng+1];
            F_select = F_all(:,select);

            %% =====| Step 1: Sample loadings L
            v = sqrt(Sigma(i,q)*k2_sq(q)*z(:,i,q));                                                    % This is the variance of the Asymetric Laplace errors
            x_tilde(:,i) = (x(:,i) - k1(q).*z(:,i,q))./v;                                              % Standardized LHS variables
            F_tilde = F_select./v;                                                                     % Standardized RHS variables
            L(select,i,q) = randn_gibbs(x_tilde(:,i),F_tilde,QL(select,i,q),T,length(select),1);       % Sample loadings Lambda
            [QL(select,i,q),~,~,lambdaL(i,select,q),tauL(i,q),nuL(i,select,q),xiL(i,q)] = ...
                horseshoe_prior(L(select,i,q)',length(select),tauL(i,q),nuL(i,select,q),xiL(i,q));   % sample prior variance of loadings Lambda

            %% =====| Step 2: Sample latent indicators z
            FL(:,i,q) = F_all*L(:,i,q);
            if ALsampler == 1             % Khare and Robert (2012)
                chi_z = sqrt(k1_sq(q) + 2*k2_sq(q))./abs(x(:,i) - squeeze(FL(:,i,q)));      % posterior moment k1 of z
                psi_z = (k1_sq(q) + 2*k2_sq(q))./(Sigma(i,q).*k2_sq(q));                    % posterior moment k2 of z
                z(:,i,q)  = min(1./random('InverseGaussian',chi_z,psi_z,T,1),1e+6);         % Sample z from Inverse Gaussian
            elseif ALsampler == 2         % Kozumi and Kobayashi (2011)
                chi_z = ((x(:,i) - squeeze(FL(:,i,q))).^2)./(Sigma(i,q).*k2_sq(q));         % posterior moment k1 of z
                psi_z = (k1_sq(q) + 2*k2_sq(q))./(Sigma(i,q).*k2_sq(q));                    % posterior moment k2 of z
                for t = 1:T
                    z(t,i,q)  = min(gigrnd(0.5,psi_z,chi_z(t),1),1e+6);                     % Sample z from Generalized Inverse Gaussian
                end
            end

            %% =====| Step 3: Sample factor regression variances Sigma
            a1 = 0.01 + 3*T/2;      sse = (x(:,i) - FL(:,i,q) - k1(q).*z(:,i,q)).^2;
            a2 = 0.01 + sum(sse./(2*z(:,i,q).*k2_sq(q))) + sum(z(:,i,q));
            Sigma(i,q) = 1./gamrnd(a1,1./a2);                                         % Sample Sigma from inverse-Gamma
        end

        % Normalize loadings: Austria (first country) has loading 1 at every quantile
        L(interX+AR1x+ng+1,:,q) = L(interX+AR1x+ng+1,:,q)./L(interX+AR1x+ng+1,1,q);

        % Create matrices for augmented state-space form (needed for sampling factors F)
        for i = 1:n
            Ftemp = [ones(T,(interX==1)), xlag(:,ARindex*i)];
            xbar(:,i,q) = (x(:,i) - Ftemp*L(1:interX+AR1x,i,q) - k1(q).*z(:,i,q))./sqrt(k2_sq(q)*z(:,i,q));
            Lbar(i,1:r,:,q) = L(interX+AR1x+ng+1:end,i,q)./sqrt(k2_sq(q)*z(:,i,q))';
            Lbar2((q-1)*n+i,:,:) = L(interX+AR1x+1:interX+AR1x+ng,i,q)./sqrt(k2_sq(q)*z(:,i,q))';
        end
        % Lc has a diagonal block with all L matrices for all quantiles
        Lc((q-1)*n+1:q*n,(q-1)*r+1:q*r,:) = Lbar(:,:,:,q);
    end
    % In the QFAVAR, Lc also has the last ng columns corresponding to variables g_{t}
    for t = 1:T
        Lc(:,end-ng+1:end,t) = Lbar2(:,:,t);
        Lfull(:,:,t) = [Lc(:,:,t); zeros(ng,r*nq) eye(ng)];
    end

    %% =====| Step 4: Sample factors [F;g]
    [F] = FFBS([xbar(:,:) g],Lfull,intF,Phic,[Sigma(:);zeros(ng,1)],Omegac,nstate);    % Forward sampling backward smoothing algorithm
    % Make sure factors are sign rotated, so that the same factor in different quantiles has the same interpretation
    for q = 1:nq
        Ctemp = corrcoef([F(:,(q-1)*r+1) fqfa(:,1,q)]);
        F(:,(q-1)*r+1) = F(:,(q-1)*r+1).*sign(Ctemp(1,2));
        L(interX+AR1x+ng+1,:,q) = L(interX+AR1x+ng+1,:,q).*sign(Ctemp(1,2));
    end

    %%%%%%%% ================================================================================================== %%%%%%%%
    %%%%%%%% ================================| State equation (VAR dynamics) |================================= %%%%%%%%
    Flag = mlag2([F(:,1:nq*r),g],p);                 % Lags of factors for VAR part (DFM state equation)
    Fy = [F(p+1:end,1:r*nq), g(p+1:end,:)];          % LHS variables for state equation (correct observations for number of lags)
    Fx = [ones(T-p,0+interF) Flag(p+1:end,:)];       % RHS variables for state equation (correct observations for number of lags)
    resid = zeros(T-p,nstate);
    A_ = eye(nstate);

    %% =====| Step 5: Sample VAR variances Omega
    se = (Fy - Fx*Phi).^2;
    if var_sv == 0
        b1 = 0.01 + (T-p)/2;
        b2 = 0.01 + sum(se)/2;
        Omega(1,:) = 1./gamrnd(b1,1./b2);                % Sample Omega from inverse-Gamma
        Omega_t = repmat(Omega,T-p,1);
    elseif var_sv == 1
        fystar  = log(se + 1e-6);                        % log squared residuals
        for i = 1:nstate
            [h(:,i), ~] = SVRW(fystar(:,i),h(:,i),sig(i,:),4);                   % log stochastic volatility using Chan's filter
            Omega_t(:,i)  = exp(h(:,i));                               % convert log-volatilities to variances
            r1 = 1 + (T-p-1)/2;   r2 = 0.01 + sum(diff(h(:,i)).^2)'/2;  % posterior moments of variance of log-volatilities
            sig(i,:) = 1./gamrnd(r1./2,2./r2);
        end
    end

    %% =====| Step 6: Sample VAR coefficients Phi
    for i = 1:nstate
        Fy_tilde = Fy(:,i)./sqrt(Omega_t(:,i));                 % Standardized LHS variables
        FX_tilde = [Fx resid(:,1:i-1)]./sqrt(Omega_t(:,i));     % Standardized RHS variables
        VAR_coeffs = randn_gibbs(Fy_tilde,FX_tilde,[QPhi(:,i);9*ones(i-1,1)],T-p,k+i-1,est_meth);   % Sample VAR coefficients Phi
        Phi(:,i) = VAR_coeffs(1:k);
        A_(i,1:i-1) = VAR_coeffs(k+1:end);
        [QPhi(:,i),~,~,lambdaPhi(i,:),tauPhi(i,1),nuPhi(i,:),xiPhi(i,1)] = horseshoe_prior(Phi(:,i)',k,tauPhi(i,1),nuPhi(i,:),xiPhi(i,1));  % sample prior variance of loadings Lambda
        resid(:,i) = Fy(:,i) - [Fx resid(:,1:i-1)]*VAR_coeffs;
    end
    Phic = [Phi(interF+1:end,:)'; eye(nstate*(p-1)) zeros(nstate*(p-1),nstate)];       % VAR coefficients in companion form
    % Ensure stationary draws
    while max(abs(eig(Phic)))>0.999
        for i = 1:nstate
            Fy_tilde = Fy(:,i)./sqrt(Omega_t(:,i));             % Standardized LHS variables
            FX_tilde = [Fx resid(:,1:i-1)]./sqrt(Omega_t(:,i)); % Standardized RHS variables
            VAR_coeffs = randn_gibbs(Fy_tilde,FX_tilde,[QPhi(:,i);9*ones(i-1,1)],T-p,k+i-1,1);   % Sample VAR coefficients Phi
            Phi(:,i) = VAR_coeffs(1:k);
            A_(i,1:i-1) = VAR_coeffs(k+1:end);
            [QPhi(:,i),~,~,lambdaPhi(i,:),tauPhi(i,1),nuPhi(i,:),xiPhi(i,1)] = horseshoe_prior(Phi(:,i)',k,tauPhi(i,1),nuPhi(i,:),xiPhi(i,1));  % sample prior variance of loadings Lambda
            resid(:,i) = Fy(:,i) - [Fx resid(:,1:i-1)]*VAR_coeffs;
        end
        Phic = [Phi(interF+1:end,:)'; eye(nstate*(p-1)) zeros(nstate*(p-1),nstate)];       % VAR coefficients in companion form
    end
    intF(:,1:nstate) = (interF==1)*repmat(Phi(1,:),T,1);
    OMEGA(:,:,1:p) = repmat(A_*diag(Omega_t(1,:))*A_',1,1,p);
    for t = 1:T-p
        OMEGA(:,:,t+p) = A_*diag(Omega_t(t,:))*A_';
    end
    Omegac(1:nstate,1:nstate,:) = OMEGA;

    %% Do stuff after burn-in period has passed and nburn samples are discarded
    if irep > nburn && mod(irep,nthin)==0
        % Save draws of parameters
        savedraw = savedraw + 1;
        F_draws(:,:,savedraw)       = F(:,1:nq*r);
        L_draws(:,:,:,savedraw)     = L;
        Phi_draws(:,:,savedraw)     = Phi;
        Sigma_draws(:,:,savedraw)   = Sigma;
        OMEGA_draws(:,:,:,savedraw) = OMEGA;
        z_draws(:,:,:,savedraw)     = z;

        %% =======================================================================================================
        %% =================================| Structural inference (IRFs) |=======================================
        %% =====| 1) Cholesky IRFs of the state equation, state reordered as [g, F]
        %  GPR is first in g, hence first in the reordered vector: it affects
        %  everything on impact and nothing affects it on impact.
        perm_idx = [r*nq+1:nstate, 1:r*nq];        % [g, F] ordering
        inv_perm = zeros(1,nstate);
        inv_perm(perm_idx) = 1:nstate;

        ar_lags    = Phi(interF+1:end,:)';         % [nstate x nstate*p]
        OMEGA_end  = squeeze(OMEGA(:,:,end));
        OMEGA_perm = OMEGA_end(perm_idx,perm_idx);
        ar0 = {ar_lags(perm_idx,perm_idx)};
        if p>1
            for i = 2:p
                lag_i = ar_lags(:,(i-1)*nstate+1:i*nstate);
                ar0   = [ar0 lag_i(perm_idx,perm_idx)];
            end
        end
        [firf_perm] = armairf(ar0,[],'InnovCov',OMEGA_perm,'Method','orthogonalized','NumObs',nhor);
        firf_perm   = permute(firf_perm,[1,3,2]);  % (horizon, response, shock)
        firf        = firf_perm(:,inv_perm,inv_perm);   % back to [F, g] ordering

        %%  =====| 2) Map IRFs to the country panel through the measurement equation
        yirf  = zeros(nhor+AR1x,n*nq,nstate);
        LL    = zeros(n*nq,nstate);
        % stack loadings (columns ordered [g, F])
        for q = 1:nq
            LL((q-1)*n+1:q*n,1:ng) = L(interX+AR1x+1:interX+AR1x+ng,:,q)';
            LL((q-1)*n+1:q*n,(q-1)*r+1+ng:q*r+ng) = L(interX+AR1x+ng+1:end,:,q)';
        end

        if AR1x == 1
           for j = 1:nstate
               for hh = 2:nhor+AR1x
                   yirf(hh,:,j) = [firf(hh-1,r*nq+1:end,j), firf(hh-1,1:r*nq,j)]*LL(:,:)' + yirf(hh-1,:,j).*L(interX+AR1x,:);
               end
           end
           yirf = yirf(2:end,:,:);
        else
            for j = 1:nstate
                yirf(:,:,j) = [firf(:,r*nq+1:end,j), firf(:,1:r*nq,j)]*LL(:,:)';
            end
        end

        %% =====| 3) FEVD: share of each state variable's FEV due to the GPR shock
        cs = cumsum(firf.^2,1);                    % (horizon, response, shock)
        fevd_save(:,:,savedraw) = cs(:,:,gpr_shock)./sum(cs,3);

        %% =====| 4) Normalize: GPR own impact = 1 (one-SD rise in the standardized index)
        gpr_imp = firf(1,gpr_shock,gpr_shock);
        firf_save(:,:,:,savedraw) = firf/gpr_imp;
        yirf_save(:,:,:,savedraw) = yirf/gpr_imp;
    end

end
fprintf('\nElapsed time: %.1f minutes\n',toc/60)

%% save results
save(save_file,'firf_save','yirf_save','fevd_save','F_draws','L_draws','Phi_draws', ...
     'Sigma_draws','OMEGA_draws','quant','nhor','n','ng','r','nq','names','namesg', ...
     'dates','gpr_shock','x','g','sample_end','-mat','-v7.3');
fprintf('Saved to %s\n',save_file)