# Replication Files

*Cutting the Flow: Geopolitical Disruptions to Russian Oil Supply and
the Tails of Euro Area Inflation*

Markeljan Blacëri, University of Padova (markeljan.blaceri@phd.unipd.it)

## 1. Overview

These files reproduce all figures and tables of the paper. The model is
a Bayesian quantile factor-augmented VAR (QFAVAR) for year-on-year HICP
inflation in the 21 euro area member states, January 2000 – December
2025, estimated at the 10th, 50th, and 90th percentiles. A geopolitical
disruption shock to Russian oil supply is identified recursively, with
the Russia component of the oil supply disruption subindex of Iacoviello
and Tong (2026) ordered first. All other results (risk measures,
exposure analysis, counterfactual, subsamples, nonlinear VARX) are
computed from the saved posterior draws, without re-estimating the
model.

## 2. Software requirements

- MATLAB R2020b or later (the scripts use tiledlayout and
  exportgraphics).

- Statistics and Machine Learning Toolbox (prctile, random, gamrnd,
  tcdf).

- Econometrics Toolbox (armairf, used for the impulse responses in the
  main estimation).

## 3. Folder structure

- Folder **functions** contains all the functions necessary to run the
  QFAVAR model. It contains the original functions from Korobilis and
  Schröder (2025), which are not modified.

- Folder **Additional functions** contains the additional functions
  written for this paper: plotting helpers (band, band_line, band_panel,
  band_plot, draw_irf, finish_axes, separator, style_axes), functions for
  the counterfactual (impact, irf_path, irf_unit, measure_fun,
  measure_name), for the nonlinear VARX (varx_irf, var_labels, lagmat,
  lagmat_rows), and for reading the exposure data (read_years,
  readSheet).

- Folder **data** contains the main data for the estimation of the
  QFAVAR model (Main Data.xlsx, sheets Inflation and Global) and the
  function that loads them (load_data.m).

- Folder **Additional data** contains the data for the exposure analysis
  (Exposure Data.xlsx): HICP item weights and the shares of Russia in
  net imports of oil and petroleum products and of natural gas, by
  country of origin.

- Folder **output** is created by the scripts and stores the posterior
  draws (.mat), the exposure measure, the LaTeX tables, and, in
  output/figures, the exported figures.

## 4. Data sources

All series are publicly available. Sources and transformations are
described in the data appendix of the paper.

| **Series**                                             | **Source**                                                      |
|--------------------------------------------------------|-----------------------------------------------------------------|
| HICP inflation, 21 member states (y/y)                 | Eurostat (prc_hicp_minr)                                        |
| Russia component of the oil supply disruption subindex | Iacoviello and Tong (2026), AI-GPR data page                    |
| Brent crude oil price                                  | FRED (DCOILBRENTEU)                                             |
| Natural gas price, Europe                              | FRED (PNGASEUUSDM)                                              |
| US dollar / euro exchange rate                         | ECB (EXR.M.USD.EUR.SP00.A)                                      |
| Composite Indicator of Systemic Stress (CISS)          | ECB (new CISS, CISS.D.U2.Z0Z.4F.EC.SS_CIN.IDX), monthly average |
| Global Supply Chain Pressure Index (GSCPI)             | Federal Reserve Bank of New York                                |
| Euro area unemployment rate                            | ECB (LFSI.M.I10.S.UNEHRT.TOTAL0.15_74.T)                        |
| Shadow rate                                            | Wu and Xia (2020), September 2004 - August 2022                 |
| EONIA (before September 2004)                          | ECB (FM.M.U2.EUR.4F.MM.EONIA.HSTA), minus 8.5 basis points      |
| Euro short-term rate (after August 2022)               | ECB (EST.B.EU000A2X2A25.WT), monthly average                    |
| HICP item weights (CP0452, CP0453, CP0722)             | Eurostat                                                        |
| Russian share of net imports by country of origin      | Eurostat (nrg_ind_idooil, nrg_ind_idogas)                       |

Main Data.xlsx also contains the sheets Oil and Gas Prices (prices in
dollars, conversion to euros, year-on-year growth rates) and Shadow Rate
(construction of the policy rate series from the shadow rate, EONIA, and
the euro short-term rate). The sheets Inflation and Global are read by
load_data.m.

## 5. How to run the files

Set the MATLAB working directory to the main folder (the one containing
the scripts and the four folders above) and run the scripts in the
following order. In every script, set save_figs = true to export the
figures to output/figures.

1.  main.m estimates the QFAVAR and saves the posterior draws and
    impulse responses. Run it three times, setting sample_end to \[\]
    (full sample, baseline), 2021, and 2019. Output:
    output/QFAVAR_russia.mat, QFAVAR_russia_2021.mat,
    QFAVAR_russia_2019.mat.

2.  plots.m produces the figures of the index and of the main
    results.

3.  exposure.m builds the exposure measure and relates it to the
    country responses. It writes output/Exposure_origin.xlsx, which is
    used in step 4. It also writes output/Exposure_slopes.xlsx.

4.  counterfactual_outcomes.m computes the counterfactual without the
    disruption shocks and writes the LaTeX tables of contributions.

5.  subsample_compare.m compares the estimates across the three samples
    (requires the three files of step 1).

6.  varx.m estimates the nonlinear VARX and produces the
    responses to shocks of different size.

## 6. Correspondence between scripts and results

| **Script**               | **Figures and tables in the paper**                                                                                                                                                                                                                      |
|--------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| plots.m                  | Disruption index and main events; identified shocks; responses of the euro area percentiles and of upside and downside risk; responses by member state (percentiles and risks); responses of the global factors; fitted quantiles and realized inflation |
| exposure.m               | Exposure to Russian oil and gas by member state; peak responses and impact upside risk against exposure                                                                                                                                                  |
| counterfactual_outcomes.m| Euro area quantiles with and without the disruption; contributions by member state against exposure; monthly contributions by member state; tables of average and peak contributions                                                                     |
| subsample_compare.m      | Responses across estimation samples (percentiles, global factors, risks); upside risk on impact by member state across samples                                                                                                                           |
| varx.m                   | Responses to typical and large disruptions (percentiles and risks); responses to shocks of the size of historical episodes                                                                                                                               |

The table of expected and estimated signs of the supply and demand
channels is written by hand from the responses of the global factors.

## 7. Running time and reproducibility

- The estimation in main.m runs 52,000 MCMC iterations (2,000 burn-in,
  thinning 50).

- All other scripts run in a few minutes, since they use the saved
  draws.

- The random seed is fixed (rng(1)) in main.m and varx.m, so
  the results are reproduced exactly with the same MATLAB version.

## 8. References

Iacoviello, M. and J. Tong (2026). The AI-GPR Index: Measuring
Geopolitical Risk using Artificial Intelligence.

Korobilis, D. and M. Schröder (2025). Monitoring multi-country
macroeconomic risk: A quantile factor-augmented vector autoregressive
(QFAVAR) approach. Journal of Econometrics, 249(C), 105730.

Wu, J. C. and F. D. Xia (2020). Negative interest rate policy and the
yield curve. Journal of Applied Econometrics, 35(6), 653–672.
