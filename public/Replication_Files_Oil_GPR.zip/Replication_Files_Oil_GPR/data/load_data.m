function [x, xlag, T, n, k, g, ng, dates, names, namesg, tcode] = ...
    load_data(standar, r, p, interF, quant, dfm, sample_end)
% =========================================================================
% load_data.m  --  Data loader for QFAVAR
% Paper: Geopolitical Risk and Euro Area Inflation Tail Risks
% =========================================================================
%
% Panel x : 21 Eurozone member states HICP inflation (sheet: Inflation)
% Block g : [russia_gpr, oil_inflation, gas_inflation, ciss, gscpi, urate, shadow_rate]
%
%   russia_gpr       : Russia oil GPR index (level)
%   oil_inflation    : Brent oil price inflation
%   gas_inflation    : European gas price inflation
%   ciss             : ECB Composite Indicator of Systemic Stress
%   gscpi            : Global supply chain pressure index
%   urate            : EA unemployment rate
%   shadow_rate      : ECB shadow short rate
%
% GPR shock index: r*nq + 1 (GPR always first in g); ng = 7
%
% Arguments:
%   standar  : 0=none; 1=standardize x; 2=standardize x and g
%   r        : number of factors (1 for single inflation panel)
%   p        : number of VAR lags
%   interF   : 1=include intercept in state equation
%   quant    : vector of quantile levels, e.g. [0.1, 0.5, 0.9]
%   dfm      : 0=QFAVAR; 1=QDFM
%   sample_end : (optional) last month of the sample, e.g. datetime(2021,12,1);
%                [] or omitted = full sample
% =========================================================================

%% -----------------------------------------------------------------------
%  1. READ DATA
%% -----------------------------------------------------------------------
fname = fullfile('data', 'Main Data.xlsx');

raw_x = readtable(fname, 'Sheet', 'Inflation', 'VariableNamingRule', 'preserve');
raw_g = readtable(fname, 'Sheet', 'Global',    'VariableNamingRule', 'preserve');

% Drop empty rows at the bottom of the sheets
raw_x = raw_x(~isnat(raw_x{:, 'month'}), :);
raw_g = raw_g(~isnat(raw_g{:, 'month'}), :);

% Optional: end the sample earlier (standardization then uses this sample only)
if nargin < 7, sample_end = []; end
% Accept a year (2021 -> Dec 2021), [year month], text ('2021-12') or datetime
if ~isempty(sample_end) && ~isdatetime(sample_end)
    if isnumeric(sample_end) && isscalar(sample_end)
        sample_end = datetime(sample_end, 12, 1);
    elseif isnumeric(sample_end) && numel(sample_end) == 2
        sample_end = datetime(sample_end(1), sample_end(2), 1);
    else
        sample_end = datetime(sample_end);
    end
end
if ~isempty(sample_end)
    raw_x = raw_x(raw_x{:, 'month'} <= sample_end, :);
    raw_g = raw_g(raw_g{:, 'month'} <= sample_end, :);
end
assert(isequal(raw_x{:, 'month'}, raw_g{:, 'month'}), 'load_data: months differ between Inflation and Global sheets');

%% -----------------------------------------------------------------------
%  2. COUNTRY PANEL: all 21 Eurozone member states
%% -----------------------------------------------------------------------
ea21 = {'Austria','Belgium','Bulgaria','Croatia','Cyprus','Estonia', ...
        'Finland','France','Germany','Greece','Ireland','Italy', ...
        'Latvia','Lithuania','Luxembourg','Malta','Netherlands', ...
        'Portugal','Slovakia','Slovenia','Spain'};

n     = length(ea21);       % 21
x_raw = raw_x{:, ea21};     % [T x 21]

%% -----------------------------------------------------------------------
%  3. DATES
%% -----------------------------------------------------------------------
date_raw   = raw_x{:, 'month'};
T          = length(date_raw);
month_abbr = {'Jan','Feb','Mar','Apr','May','Jun', ...
              'Jul','Aug','Sep','Oct','Nov','Dec'};
dates = cell(T, 1);
for t = 1:T
    dates{t} = sprintf('%d%s', year(date_raw(t)), month_abbr{month(date_raw(t))});
end

%% -----------------------------------------------------------------------
%  4. BUILD g BLOCK  (GPR first -- most exogenous, shock of interest)
%% -----------------------------------------------------------------------
g_vars = {'russia_gpr', 'oil_inflation', 'gas_inflation', 'ciss', 'gscpi', 'urate', 'shadow_rate'};
namesg = g_vars;

missing_vars = setdiff(g_vars, raw_g.Properties.VariableNames);
if ~isempty(missing_vars)
    error('load_data: missing variables in Global sheet: %s', strjoin(missing_vars, ', '));
end

g_raw = raw_g{:, g_vars};   % [T x ng]
ng    = size(g_raw, 2);     % = 7

%% -----------------------------------------------------------------------
%  5. MISSING VALUES -- interpolate if any
%% -----------------------------------------------------------------------
for j = 1:ng
    col = g_raw(:, j);
    if any(isnan(col))
        idx   = find(~isnan(col));
        idx_n = find(isnan(col));
        if length(idx) < 2
            error('load_data: too many NaNs in %s to interpolate', namesg{j})
        end
        col(idx_n) = interp1(idx, col(idx), idx_n, 'linear', 'extrap');
        g_raw(:, j) = col;
        fprintf('load_data: interpolated %d missing value(s) in %s\n', ...
                length(idx_n), namesg{j});
    end
end

%% -----------------------------------------------------------------------
%  6. STANDARDIZATION
%% -----------------------------------------------------------------------
x = x_raw;
g = g_raw;
if standar >= 1; x = (x - mean(x)) ./ std(x); end
if standar >= 2; g = (g - mean(g)) ./ std(g); end

%% -----------------------------------------------------------------------
%  7. LAG MATRIX AND DIMENSION k
%% -----------------------------------------------------------------------
xlag = [NaN(1, n); x(1:end-1, :)];
nq   = length(quant);
k    = (r * nq + ng) * p + interF;

if dfm == 1
    g = []; ng = 0;
    k = (r * nq) * p + interF;
end

%% -----------------------------------------------------------------------
%  8. NAMES AND TRANSFORMATION CODES
%% -----------------------------------------------------------------------
names = strcat('HICP.', ea21(:));   % [21 x 1]
tcode = ones(n, 1);

%% -----------------------------------------------------------------------
%  9. SANITY CHECKS
%% -----------------------------------------------------------------------
assert(size(x,1) == T, 'load_data: row mismatch x vs dates');
assert(size(x,2) == n, 'load_data: x columns != n=21');
assert(~any(isnan(x(:))), 'load_data: NaNs remain in x');
if dfm == 0
    assert(size(g,1) == T, 'load_data: row mismatch g vs dates');
    assert(~any(isnan(g(:))), 'load_data: NaNs remain in g');
end

fprintf('load_data: T=%d, n=%d (EA21), ng=%d, r=%d, nq=%d, p=%d\n', T, n, ng, r, nq, p);
fprintf('load_data: sample %s to %s\n', dates{1}, dates{end});
fprintf('load_data: g = [%s]\n', strjoin(namesg, ', '));
fprintf('load_data: GPR shock index = r*nq + 1 = %d\n', r*nq+1);

end