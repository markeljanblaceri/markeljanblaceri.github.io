%==========================================================================
% Cutting the Flow: Geopolitical Disruptions to Russian Oil Supply and the
% Tails of Euro Area Inflation
%
% Markeljan Blaceri, University of Padova
%
% Replication files -- does the size of the disruption matter? (nonlinear VARX)
%==========================================================================
% Run after QFAVAR_main.m (full sample). No re-estimation of the QFAVAR:
% everything comes from the saved posterior draws. Two-step approach of
% Brignone, Gambetti and Ricci, following Debortoli et al. (2020) and
% Forni et al. (2023):
%
%  Step 1. For each posterior draw, recover the structural disruption shock.
%          With the index ordered first, the shock is the reduced-form
%          residual of the index equation scaled by its standard deviation:
%              eps_t = u_S,t / sqrt(Omega_S,S)
%
%  Step 2. For each draw, estimate by OLS the VARX (and, if draw_ols, take
%          one draw of its coefficients from their sampling distribution)
%              z_t = c + D_1 z_{t-1} + ... + D_py z_{t-py}
%                      + b eps_t + d nl(eps_t) + u_t ,   nl(eps) = eps^2,
%          where z_t = [quantile factors, global factors except the index]
%          (the QFAVAR state vector with the index replaced by the shock).
%          The response to a shock of size delta is b*delta + d*nl(delta) on
%          impact, propagated through the D matrices. In a linear model
%          (d = 0) the response per unit of shock is the same for every delta.
%
% Figures:
%   1  The identified shock and its square
%   2  Percentile responses to a typical (40 points, 1 s.d.) and a large
%      (360 points, 9 s.d.) shock, per 100 index points
%   3  Upside and downside risk, same shocks, per 100 index points
%   4  Responses to shocks of the size of historical episodes (normal times,
%      Russo-Georgian war, annexation of Crimea, Russo-Ukrainian war),
%      rows = variables in z_t, total responses
% The console reports the largest shocks, the impact coefficients b and d,
% and the shock sizes at which the impact responses change sign.
%
% Helper functions (var_labels, varx_irf, draw_irf, lagmat, lagmat_rows,
% style_axes) are in 'Additional functions'.
%==========================================================================

clear; clc; close all;
rng(1);                                        % reproducible second-step draws
addpath('functions'); addpath('data'); addpath('Additional functions')

%---------------------------| USER INPUT |---------------------------------
res_file  = fullfile('output','QFAVAR_russia.mat');
g_add     = 'all';               % 'all' = every global factor except the index (baseline, same z_t as the QFAVAR);
                                 % or a cell of names in namesg, e.g. {'gas_inflation'}; {} = factors only
py        = 2;                   % lags of z in the VARX
q         = 0;                   % lags of the shock (0 = only contemporaneous eps, nl(eps))
nonlin    = 'square';            % 'square' = eps^2 (baseline, as in Brignone et al.)
                                 % 'signed' = eps*|eps| (keeps the sign of large shocks)
pts       = [40 360];            % Figures 2-3: shock sizes in index points (about 1 and 9 s.d. of the shock); up to 4
pts_lab   = {'Typical shock (1 s.d.)', 'Large shock (9 s.d.)'};
per_pts   = 100;                 % Figures 2-3: responses per per_pts index points ([] = total)
plot_v    = 1:3;                 % Figure 2: variables shown (1:3 = percentiles; 1:ny = all)
nhor_v    = 24;                  % IRF horizon (months)
bands     = [16 84];             % 68% bands
draw_ols  = true;                % true = bands include the sampling uncertainty of the second-step VARX

% Figure 4: historical episodes ('' = one standard deviation of the shock)
ep_lab    = {'Normal times', 'Russo-Georgian war', 'Annexation of Crimea', 'Russo-Ukrainian war'};
ep_month  = {'',             '2008Aug',            '2014Mar',              '2022Mar'};
ep_pts    = [];                  % optional override of the sizes in index points
same_y    = false;               % true = same y-axis within each row of Figure 4
ep_pts_title = false;            % true = show the shock size (points) in the Figure 4 column titles
ep_xlabel    = false;            % true = 'Months after the shock' below Figure 4
save_figs = false;               % true = export the figures to fig_dir
fig_dir   = fullfile('output','figures');
%--------------------------------------------------------------------------

load(res_file, 'F_draws','Phi_draws','OMEGA_draws','g','n','ng','r','nq', ...
     'namesg','dates','gpr_shock','quant');
vars_in = who('-file', res_file);
if ismember('sample_end', vars_in), load(res_file, 'sample_end'); else, sample_end = []; end

[T, ~, ndraw] = size(F_draws);
nstate = r*nq + ng;
k      = size(Phi_draws,1);
interF = mod(k, nstate);
p      = (k - interF) / nstate;
fprintf('QFAVAR: T = %d, p = %d, interF = %d, draws = %d\n', T, p, interF, ndraw);

% Units: factors in pp (cross-country mean SD), globals in own units
[x_raw,~,~,~,~,g_raw] = load_data(0, r, 1, 0, quant, 0, sample_end);
sd_f = mean(std(x_raw));
sd_g = std(g_raw);
ig_S = gpr_shock - r*nq;                       % position of the disruption index in g
sd_S = sd_g(ig_S);                             % SD of the index (points)

% Global variables in z_t ('all' accepted as text or as {'all'})
if (ischar(g_add) || isstring(g_add)) && strcmp(g_add, 'all') || (iscell(g_add) && isequal(g_add, {'all'}))
    ig = setdiff(1:ng, ig_S);
else
    ig = find(ismember(namesg, g_add));
    miss = setdiff(g_add, namesg);
    if ~isempty(miss), warning('Not in namesg: %s', strjoin(miss, ', ')); end
end

% Names: one line (Figures 2-3, printout) and two lines with units (Figure 4)
nice = struct('oil_inflation','Oil price inflation', 'gas_inflation','Gas price inflation', ...
              'ciss','CISS', 'gscpi','GSCPI', 'urate','Unemployment rate', 'shadow_rate','Shadow rate');
lab2 = struct('oil_inflation',{{'Oil price','inflation (pp)'}}, 'gas_inflation',{{'Gas price','inflation (pp)'}}, ...
              'ciss',{{'CISS','(index)'}}, 'gscpi',{{'GSCPI','(std. dev.)'}}, ...
              'urate',{{'Unemployment','rate (pp)'}}, 'shadow_rate',{{'Shadow','rate (pp)'}});
[gn, g2] = var_labels(namesg(ig), nice, lab2);
ynames  = [{'10th Percentile','50th Percentile','90th Percentile'}, gn];
ynames2 = [{{'10th','percentile (pp)'}, {'50th','percentile (pp)'}, {'90th','percentile (pp)'}}, g2];
yscale  = [sd_f*ones(1,nq), sd_g(ig)];
ny      = numel(ynames);
ns      = numel(pts);

%% ======| Step 1 + 2, draw by draw
switch nonlin
    case 'square', nl = @(e) e.^2;       nlname = 'eps^2';
    case 'signed', nl = @(e) e.*abs(e);  nlname = 'eps*|eps|';
    otherwise, error('nonlin must be ''square'' or ''signed''.');
end
fprintf('Nonlinear term: %s\nVARX variables (%d): %s\n', nlname, ny, strjoin(ynames, ', '));
irf     = zeros(nhor_v, ny, ns, ndraw);
b0      = zeros(ny, ndraw);  c0 = b0;          % impact coefficients on eps and nl(eps) (standardized)
dstar   = nan(ny, ndraw);                      % size (points) at which the impact response changes sign
eps_all = zeros(T-p, ndraw);
A_all   = zeros(ny, ny*py, ndraw);             % kept for Figure 4
bc_all  = zeros(ny, 2*(q+1), ndraw);
p2e_all = zeros(1, ndraw);                     % eps units per index point
for d = 1:ndraw
    % Step 1: structural disruption shock (unit = one SD of the innovation)
    Z  = [F_draws(:,:,d), g];
    U  = Z(p+1:end, :) - [ones(T-p, interF), lagmat(Z, p)] * Phi_draws(:,:,d);
    Om = OMEGA_draws(:,:,end,d);
    s_eps = sqrt(Om(gpr_shock, gpr_shock));     % impact of one eps on the (standardized) index
    eps = U(:, gpr_shock) / s_eps;
    eps_all(:,d) = eps;
    pts2eps = 1 / (s_eps * sd_S);               % eps units per index point
    p2e_all(d) = pts2eps;

    % Step 2: VARX on z = [factors, globals except the index]
    y  = [F_draws(p+1:end,:,d), g(p+1:end, ig)];
    m  = max(py, q);
    Yv = y(m+1:end, :);
    Xv = [ones(size(Yv,1),1), lagmat_rows(y, py, m)];
    E  = zeros(size(Yv,1), 2*(q+1));
    for j = 0:q
        E(:, 2*j+1) = eps(m+1-j:end-j);
        E(:, 2*j+2) = nl(eps(m+1-j:end-j));
    end
    XX = [Xv, E];
    B  = XX \ Yv;                                 % OLS point estimate
    if draw_ols                                   % one draw from the OLS sampling distribution
        res  = Yv - XX*B;
        Teff = size(XX,1);  kx = size(XX,2);
        Sig  = (res'*res) / (Teff - kx);          % residual covariance
        iXX  = (XX'*XX) \ eye(kx);
        B    = B + chol(iXX, 'lower') * randn(kx, ny) * chol(Sig);   % vec(B) ~ N(vec(B_ols), Sig kron (X'X)^-1)
    end
    A  = B(2:1+ny*py, :)';
    bc = B(2+ny*py:end, :)';
    A_all(:,:,d) = A;  bc_all(:,:,d) = bc;
    b0(:,d) = bc(:,1);  c0(:,d) = bc(:,2);
    dstar(:,d) = -bc(:,1) ./ bc(:,2) / pts2eps;   % b*delta + d*nl(delta) = 0

    % IRFs for each shock size (Figures 2-3)
    for s = 1:ns
        R = varx_irf(A, bc, pts(s) * pts2eps, nl, nhor_v, py, q);
        if isempty(per_pts), irf(:,:,s,d) = R .* yscale;
        else,                irf(:,:,s,d) = R / pts(s) * per_pts .* yscale; end
    end
end

%% ======| Diagnostics
eps_md = median(eps_all, 2);
dd     = dates(p+1:end);
[~, ord] = sort(abs(eps_md), 'descend');
fprintf('\nLargest disruption shocks (posterior median, in SD of the innovation):\n');
for j = 1:8, fprintf('  %s  %6.2f\n', dd{ord(j)}, eps_md(ord(j))); end
fprintf('Months with |eps| > 3: %d\n', sum(abs(eps_md) > 3));

fprintf('\nImpact coefficients (standardized units): eps (linear, b) and %s (nonlinear, d)\n', nlname);
for v = 1:ny
    fprintf('  %-22s b: %7.3f [%6.3f, %6.3f] | d: %7.3f [%6.3f, %6.3f], P(d > 0) = %.2f\n', ynames{v}, ...
        median(b0(v,:)), prctile(b0(v,:),16), prctile(b0(v,:),84), ...
        median(c0(v,:)), prctile(c0(v,:),16), prctile(c0(v,:),84), mean(c0(v,:) > 0));
end
fprintf('\nShock size at which the impact response changes sign (index points, if b and d differ in sign):\n');
for v = 1:ny
    ok = sign(b0(v,:)) ~= sign(c0(v,:)) & dstar(v,:) > 0;
    if mean(ok) > 0.5
        fprintf('  %-22s median %6.0f points (sign change in %.0f%% of draws)\n', ynames{v}, median(dstar(v,ok)), 100*mean(ok));
    else
        fprintf('  %-22s no sign change in most draws\n', ynames{v});
    end
end

%% ======| Style
% One light blue for every figure (edit these lines to restyle all figures).
c_line = [0.13 0.47 0.80];                       % light blue: lines
c_band = [0.55 0.76 0.95];                       % lighter blue: 68% bands
% Figures 2-3 overlay several shock sizes in one panel: the first size uses the
% light blue, the larger sizes darker shades of the same blue (see legend).
cols   = [c_line; 0.05 0.20 0.50; 0.03 0.12 0.32; 0.02 0.06 0.20];
hz     = (1:nhor_v)';                            % 1 = impact
if isempty(per_pts), ylab_irf = 'Percentage points'; else, ylab_irf = sprintf('Per %d index points', per_pts); end
fs     = 10;                                     % font size, Figures 1-3
fs_s   = 8;                                      % font size, Figure 4 (many panels)
mult1  = {'TitleFontSizeMultiplier', 1, 'LabelFontSizeMultiplier', 1};   % no automatic enlargement
if save_figs && ~exist(fig_dir, 'dir'), mkdir(fig_dir); end

%% ======| Figure 1: the disruption shock and its nonlinear term
ddt   = datenum(datetime(dd, 'InputFormat', 'yyyyMMM'));
e_lo  = prctile(eps_all, bands(1), 2);  e_hi = prctile(eps_all, bands(2), 2);
e2    = nl(eps_all);

fig1 = figure('Name','Disruption shock and its nonlinear term','Color','w','Position',[50 100 1100 520]);
tiledlayout(2, 1, 'TileSpacing','compact', 'Padding','compact');

% Tile 1
nexttile; hold on
fill([ddt; flipud(ddt)], [e_lo; flipud(e_hi)], c_band, 'FaceAlpha', 0.6, 'EdgeColor','none');
plot(ddt, mean(eps_all,2), 'Color', c_line, 'LineWidth', 1.2);
yline(0, '--', 'Color', [0 0 0]);
hold off; 
style_axes(gca); 
xlim([ddt(1) ddt(end)]); 
datetick('x','yyyy','keeplimits');
set(gca, 'FontSize', fs, mult1{:})
title('Structural shock \epsilon_t', 'FontSize', fs, 'FontWeight', 'normal'); 
ylabel('Std. dev.', 'FontSize', fs);

% Tile 2
nexttile; hold on
fill([ddt; flipud(ddt)], [prctile(e2,bands(1),2); flipud(prctile(e2,bands(2),2))], c_band, ...
     'FaceAlpha', 0.6, 'EdgeColor','none');
plot(ddt, mean(e2,2), 'Color', c_line, 'LineWidth', 1.2);
hold off; 
style_axes(gca); 
xlim([ddt(1) ddt(end)]); 
datetick('x','yyyy','keeplimits');

set(gca, 'FontSize', fs, mult1{:})
if strcmp(nonlin,'square')
    title('Squared shock \epsilon_t^2', 'FontSize', fs, 'FontWeight', 'normal');
else
    title('Signed squared shock \epsilon_t|\epsilon_t|', 'FontSize', fs, 'FontWeight', 'normal'); 
end
ylabel('Std. dev. squared', 'FontSize', fs);
if save_figs, exportgraphics(fig1, fullfile(fig_dir, 'varx_shock.png'), 'Resolution', 300); end

%% ======| Figure 2: responses by shock size (one panel per variable)
nv = numel(plot_v);
fig2 = figure('Name','Nonlinear VARX: responses by shock size','Color','w','Position',[50 80 330*nv 360]);
tiledlayout(1, nv, 'TileSpacing','compact', 'Padding','compact');

for kk = 1:nv
    v = plot_v(kk);
    nexttile; hh = gobjects(ns,1);
    for s = 1:ns
        hh(s) = draw_irf(hz, squeeze(irf(:,v,s,:)), bands, s, cols(s,:), c_band); 
    end
    plot(hz, zeros(size(hz)), '--', 'Color', [0 0 0], 'LineWidth', 1, 'HandleVisibility','off'); 
    hold off;
    
    style_axes(gca); 
    
    xlim([hz(1) hz(end)]);
    set(gca, 'FontSize', fs, mult1{:})
    title(ynames{v}, 'FontSize', fs, 'FontWeight', 'normal');
    
    if kk == 1
        ylabel(ylab_irf, 'FontSize', fs);
        lg = legend(hh, pts_lab, 'Orientation','horizontal', 'Box','off', 'FontSize', fs);  
        lg.Layout.Tile = 'south';
    end
end
if save_figs, exportgraphics(fig2, fullfile(fig_dir, 'varx_percentiles.png'), 'Resolution', 300); end

%% ======| Figure 3: upside and downside risk by shock size
fig3 = figure('Name','Nonlinear VARX: tail risks by shock size','Color','w','Position',[100 100 900 360]);
tiledlayout(1, 2, 'TileSpacing','compact', 'Padding','compact');
rk = {@(s) squeeze(irf(:,3,s,:) - irf(:,2,s,:)), @(s) squeeze(irf(:,2,s,:) - irf(:,1,s,:))};
rn = {'Upside Risk', 'Downside Risk'};

for k2 = 1:2
    nexttile; hh = gobjects(ns,1);
    for s = 1:ns
        hh(s) = draw_irf(hz, rk{k2}(s), bands, s, cols(s,:), c_band); 
    end
    plot(hz, zeros(size(hz)), '--', 'Color', [0 0 0], 'LineWidth', 1, 'HandleVisibility','off'); 
    hold off;
    
    style_axes(gca); 
    
    xlim([hz(1) hz(end)]);
    set(gca, 'FontSize', fs, mult1{:})
    title(rn{k2}, 'FontSize', fs, 'FontWeight', 'normal');
    
    if k2 == 1
        ylabel(ylab_irf, 'FontSize', fs);
        lg = legend(hh, pts_lab, 'Orientation','horizontal', 'Box','off', 'FontSize', fs);  
        lg.Layout.Tile = 'south';
    end
end
if save_figs, exportgraphics(fig3, fullfile(fig_dir, 'varx_risks.png'), 'Resolution', 300); end

%% ======| Figure 4: historical episodes (rows = variables, columns = shock sizes)
ne = numel(ep_lab);
pts_per_eps = 1 ./ p2e_all;                      % index points per unit of eps, by draw
if isempty(ep_pts)
    ep_pts = zeros(1, ne);
    for e = 1:ne
        if isempty(ep_month{e})
            ep_pts(e) = median(pts_per_eps);                         % one SD of the shock
        else
            it = find(strcmp(dd, ep_month{e}));
            assert(~isempty(it), 'Month %s not in the sample.', ep_month{e});
            ep_pts(e) = median(eps_all(it,:) .* pts_per_eps);       % shock realized in that month
        end
    end
end
fprintf('\nFigure 4, shock sizes (index points | SD of the shock, median):\n');
for e = 1:ne
    fprintf('  %-22s %7.1f | %5.2f\n', ep_lab{e}, ep_pts(e), ep_pts(e) / median(pts_per_eps));
end
irf_ep = zeros(nhor_v, ny, ne, ndraw);           % total responses
for d = 1:ndraw
    for e = 1:ne
        R = varx_irf(A_all(:,:,d), bc_all(:,:,d), ep_pts(e) * p2e_all(d), nl, nhor_v, py, q);
        irf_ep(:,:,e,d) = R .* yscale;
    end
end
fig4 = figure('Name','Nonlinear VARX: historical episodes','Color','w','Position',[40 20 1150 min(1500, 170*ny)]);
tl4  = tiledlayout(ny, ne, 'TileSpacing','compact', 'Padding','compact');
ax4  = gobjects(ny, ne);
for v = 1:ny
    for e = 1:ne
        ax4(v,e) = nexttile;  hold on
        D  = squeeze(irf_ep(:,v,e,:));
        lo = prctile(D, bands(1), 2);  hi = prctile(D, bands(2), 2);
        fill([hz; flipud(hz)], [lo; flipud(hi)], c_band, 'EdgeColor','none', 'FaceAlpha', 0.6);
        plot(hz, median(D,2), '-', 'Color', c_line, 'LineWidth', 1.6);
        yline(0, '--', 'Color', [0 0 0], 'LineWidth', 0.8);
        hold off;  
        
        style_axes(ax4(v,e));  
        
        xlim([hz(1) hz(end)]);  set(ax4(v,e), 'FontSize', fs_s, mult1{:})
        if v == 1
            if ep_pts_title, title({ep_lab{e}, sprintf('(%.0f points)', ep_pts(e))}, 'FontSize', fs_s, 'FontWeight', 'normal');
            else,            title(ep_lab{e}, 'FontSize', fs_s, 'FontWeight', 'normal'); end
        end
        if e == 1, ylabel(ynames2{v}, 'FontSize', fs_s); end       % two-line label
        if v < ny, set(ax4(v,e), 'XTickLabel', {}); end
    end
    if same_y, linkaxes(ax4(v,:), 'y'); end
end
if ep_xlabel, xlabel(tl4, 'Months after the shock', 'FontSize', fs_s); end
if save_figs, exportgraphics(fig4, fullfile(fig_dir, 'varx_episodes.png'), 'Resolution', 300); end
% Impact and peak responses (median), for the text
fprintf('\nFigure 4, median response: impact | peak (month, 1 = impact) | 68%% band at the peak\n');
for v = 1:ny
    fprintf('%s\n', ynames{v});
    for e = 1:ne
        md = median(squeeze(irf_ep(:,v,e,:)), 2);
        [~, hp] = max(abs(md));
        Dp = squeeze(irf_ep(hp,v,e,:));
        fprintf('   %-22s %7.3f | %7.3f (h=%2d) | [%7.3f, %7.3f]\n', ep_lab{e}, md(1), md(hp), hp, ...
                prctile(Dp,bands(1)), prctile(Dp,bands(2)));
    end
end